#!/usr/bin/env bash
# Register + enrol identities carrying the `uid` and `role` attributes the chaincode reads.
# Adapted from fabric-samples/test-network (Org1 CA on localhost:7054). Review paths for your setup.
set -euo pipefail
FS="${FABRIC_SAMPLES:-$HOME/fabric-samples}"
export PATH="$FS/bin:$PATH"
ORG1="$FS/test-network/organizations/peerOrganizations/org1.example.com"
export FABRIC_CA_CLIENT_HOME="$ORG1"
CA_TLS="$FS/test-network/organizations/fabric-ca/org1/ca-cert.pem"
URL="https://localhost:7054"

enroll() {  # name role
  local name=$1 role=$2
  fabric-ca-client register --caname ca-org1 --id.name "$name" --id.secret "${name}pw" --id.type client \
      --id.attrs "uid=$name:ecert,role=$role:ecert" --tls.certfiles "$CA_TLS" || true
  fabric-ca-client enroll -u "https://$name:${name}pw@localhost:7054" --caname ca-org1 \
      -M "$ORG1/users/$name@org1.example.com/msp" --enrollment.attrs "uid,role" --tls.certfiles "$CA_TLS"
  cp "$ORG1/msp/config.yaml" "$ORG1/users/$name@org1.example.com/msp/config.yaml"
}

enroll admin-1   admin
enroll edge-gw-1 edge
enroll cloud-svc service
enroll pat-001   patient
enroll dr-khan   physician
echo "Done. Point CORE_PEER_MSPCONFIGPATH at users/<name>@org1.example.com/msp for each FabricCLILedger."
