"""Randomised attack campaign against the ledger + storage (paper Sec. 5.3, N = 500 attempts).

    python -m scripts.simulate_attacks --n 500
Every attempt must be REJECTED / DETECTED and the system must keep serving legitimate requests.
"""
from __future__ import annotations

import argparse
import collections
import random
import secrets
import time

import numpy as np

from iomt.alerts import AlertHub
from iomt.cloud_client import LocalCloud
from iomt.crypto import generate_rsa_keypair
from iomt.edge_gateway import EdgeGateway
from iomt.ledger import LedgerError, MockLedger
from iomt.physician_client import AccessDenied, IntegrityError, PhysicianClient
from iomt.predictor import HeuristicPredictor, default_scaler
from iomt.storage import MemoryStorage


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--n", type=int, default=500); ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args(); rnd = random.Random(a.seed)
    L, S = MockLedger(), MemoryStorage(); L.bootstrap_admin("admin")
    priv, pub = generate_rsa_keypair()
    _, pub2 = generate_rsa_keypair()
    for uid, role, k in [("gw", "edge", None), ("p1", "patient", None), ("p2", "patient", None),
                         ("dr", "physician", pub), ("dr2", "physician", pub2)]:
        L.register_identity("admin", uid, role, k)
    pred = HeuristicPredictor(default_scaler())
    gw = EdgeGateway("gw", L, S, pred, LocalCloud(pred, AlertHub()))
    ids = [gw.ingest("p1", time.time() + i, np.array([140, 128, 80, 76, 97, 29.0])).record_id for i in range(5)]
    L.grant_access("p1", "p1", "dr", time.time() + 3600)           # dr has consent; dr2 does not
    doc, doc2 = PhysicianClient("dr", priv, L, S), PhysicianClient("dr2", priv, L, S)

    def unauthorised_physician():  doc2.read_record("p1", rnd.choice(ids))
    def unregistered_identity():   L.request_key("mallory", "p1", "k", time.time(), secrets.token_hex(4))
    def admin_reads_key():         L.request_key("admin", "p1", "k", time.time(), secrets.token_hex(4))
    def privilege_escalation():    L.register_identity("dr", "dr3", "admin")
    def forged_grant():            L.grant_access("dr", "p1", "dr", time.time() + 999)
    def other_patient_grants():    L.grant_access("p2", "p1", "dr2", time.time() + 999)
    def overwrite_record():        L.anchor_record("gw", rnd.choice(ids), "p1", "00" * 32, "x", "k")
    def replay_request():
        k = L.list_records("p1")[0]["key_id"]; n = secrets.token_hex(4)
        L.request_key("dr", "p1", k, time.time(), n)
        r = L.request_key("dr", "p1", k, time.time(), n)
        if r.granted: return
        raise AccessDenied(r.reason)
    def stale_request():
        k = L.list_records("p1")[0]["key_id"]
        r = L.request_key("dr", "p1", k, time.time() - 3600, secrets.token_hex(4))
        if r.granted: return
        raise AccessDenied(r.reason)
    def tamper_blob():
        rec = L.list_records("p1")[rnd.randrange(5)]; b = bytearray(S.blobs[rec["ipfs_cid"]])
        b[rnd.randrange(len(b))] ^= 1 << rnd.randrange(8)
        orig = S.blobs[rec["ipfs_cid"]]; S.blobs[rec["ipfs_cid"]] = bytes(b)
        try: doc.read_record("p1", rec["record_id"])
        finally: S.blobs[rec["ipfs_cid"]] = orig

    attacks = [unauthorised_physician, unregistered_identity, admin_reads_key, privilege_escalation, forged_grant,
               other_patient_grants, overwrite_record, replay_request, stale_request, tamper_blob]
    blocked = collections.Counter(); failed = collections.Counter()
    for _ in range(a.n):
        f = rnd.choice(attacks)
        try:
            f(); failed[f.__name__] += 1                        # attack SUCCEEDED -> bad
        except (LedgerError, AccessDenied, IntegrityError):
            blocked[f.__name__] += 1
    print(f"{sum(blocked.values())}/{a.n} attempts blocked")
    for k in attacks: print(f"  {k.__name__:26s} blocked={blocked[k.__name__]:3d} succeeded={failed[k.__name__]}")
    ok = doc.read_record("p1", ids[0])                           # service still healthy
    print("legitimate read after campaign OK:", ok["patient"] == "p1", "| chain valid:", L.verify_chain())
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
