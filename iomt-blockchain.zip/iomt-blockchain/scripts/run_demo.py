"""End-to-end demo with NO external services (mock ledger, in-memory storage, heuristic model).

    python -m scripts.run_demo
"""
from __future__ import annotations

import secrets
import sys
import time

import numpy as np

from iomt.alerts import AlertHub
from iomt.cloud_client import LocalCloud
from iomt.crypto import generate_rsa_keypair
from iomt.edge_gateway import EdgeGateway
from iomt.ledger import MockLedger
from iomt.physician_client import AccessDenied, IntegrityError, PhysicianClient
from iomt.predictor import HeuristicPredictor, default_scaler
from iomt.storage import MemoryStorage


def main() -> None:
    ledger, storage, hub = MockLedger(), MemoryStorage(), AlertHub(confirm_timeout_s=2.0)
    ledger.bootstrap_admin("admin")
    priv, pub = generate_rsa_keypair()
    for uid, role, key in [("edge-gw-1", "edge", None), ("pat-001", "patient", None), ("dr-khan", "physician", pub)]:
        ledger.register_identity("admin", uid, role, key)
    pred = HeuristicPredictor(default_scaler())
    gw = EdgeGateway("edge-gw-1", ledger, storage, pred, LocalCloud(pred, hub))
    hub.subscribe(lambda a: print(f"  >> ALERT {a['alert_id']} patient={a['patient_id']} source={a['source']} "
                                  f"risk={a['risk']} reasons={a['reasons']}"))
    hub.subscribe(lambda a: print(f"  >> FALLBACK escalation for {a['alert_id']}"), "fallback")

    print("1) Streaming a patient whose glucose is falling toward severe hypoglycemia")
    rng = np.random.default_rng(1)
    t0, last = time.time(), None
    for i, g in enumerate(np.linspace(150, 40, 16)):
        reading = np.array([g, 128, 80, 76, 97, 29]) + rng.normal(0, [2, 2, 1, 1, .1, 0])
        last = gw.ingest("pat-001", t0 + 900 * i, reading)
        print(f"  step {i:2d} glucose={reading[0]:6.1f} risk={last.risk} emergency={last.emergency} "
              f"latency={last.timings_ms['total']:.1f} ms")

    print("\n2) Ledger holds hashes + CIDs only; payloads are ciphertext")
    rec = ledger.list_records("pat-001")[-1]
    print("  anchored:", {k: rec[k] for k in ("record_id", "sha256", "ipfs_cid", "key_id")})

    print("\n3) Physician without consent is refused (and the attempt is logged)")
    doc = PhysicianClient("dr-khan", priv, ledger, storage)
    try:
        doc.read_record("pat-001", rec["record_id"])
    except AccessDenied as e:
        print("  denied:", e)

    print("\n4) Patient grants consent -> physician decrypts")
    ledger.grant_access("pat-001", "pat-001", "dr-khan", time.time() + 3600)
    print("  decrypted raw reading:", np.round(doc.read_record("pat-001", rec["record_id"])["raw"], 1))

    print("\n5) Off-chain tampering is detected via the anchored SHA-256")
    ref = rec["ipfs_cid"]; b = bytearray(storage.blobs[ref]); b[15] ^= 1; storage.blobs[ref] = bytes(b)
    try:
        doc.read_record("pat-001", rec["record_id"])
    except IntegrityError as e:
        print("  integrity error:", e)

    print("\n6) Patient revokes -> access ends immediately")
    ledger.revoke_access("pat-001", "pat-001", "dr-khan")
    try:
        doc.read_record("pat-001", rec["record_id"])
    except AccessDenied as e:
        print("  denied:", e)

    print("\n7) Unconfirmed alert escalates to the fallback path after the timeout")
    time.sleep(2.1)
    hub.check_timeouts()
    print("\nAudit log (last 4):")
    for e in ledger.get_access_log("pat-001")[-4:]:
        print("  ", e["who"], e["action"], e["outcome"], e["detail"])
    print("Ledger hash chain valid:", ledger.verify_chain())


if __name__ == "__main__":
    sys.exit(main())
