#!/usr/bin/env bash
# Bring up Fabric (test-network: 2 orgs, 1 Raft orderer, CouchDB) and deploy the chaincode.
#   FABRIC_SAMPLES=~/fabric-samples scripts/deploy_fabric.sh
# Prereqs: Docker, Fabric 2.5 binaries + fabric-samples (https://hyperledger-fabric.readthedocs.io).
set -euo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
FS="${FABRIC_SAMPLES:-$HOME/fabric-samples}"
cd "$FS/test-network"

./network.sh down
./network.sh up createChannel -c healthcare -ca -s couchdb      # CouchDB state DB + Fabric CAs
./network.sh deployCC -c healthcare -ccn healthcc -ccl go \
  -ccp "$REPO/chaincode/healthcare" \
  -ccep "OR('Org1MSP.peer','Org2MSP.peer')" \
  -cccg "$REPO/chaincode/healthcare/collections_config.json"

echo "Chaincode 'healthcc' deployed on channel 'healthcare'."
echo "Next: scripts/fabric_enroll.sh to create identities with uid/role attributes."
