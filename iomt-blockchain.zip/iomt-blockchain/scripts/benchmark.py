"""Latency / throughput benchmark of the gateway pipeline (paper Sec. 4.8, 5.1) with mean +- 95% CI.

    python -m scripts.benchmark --records 2000 --reps 5
    python -m scripts.benchmark --backend ipfs --ipfs http://127.0.0.1:5001

NOTE: with the default MockLedger/MemoryStorage this measures only the Python edge pipeline
(Kalman + AES-GCM + SHA-256 + bookkeeping). Numbers comparable to the paper's (142.5 ms,
845 TPS) require --backend ipfs and a real Fabric network (FabricCLILedger).
"""
from __future__ import annotations

import argparse
import statistics as st
import time

import numpy as np

from iomt.alerts import AlertHub
from iomt.cloud_client import LocalCloud
from iomt.edge_gateway import EdgeGateway
from iomt.ledger import MockLedger
from iomt.predictor import HeuristicPredictor, default_scaler
from iomt.storage import IPFSStorage, MemoryStorage

# two-sided 95% Student-t critical values by number of repetitions (falls back to 1.96)
_T = {2: 12.71, 3: 4.30, 4: 3.18, 5: 2.78, 10: 2.26, 30: 2.05}


def ci95(xs):
    n = len(xs)
    if n < 2:
        return st.mean(xs), 0.0
    t = _T.get(n, 1.96)
    return st.mean(xs), t * st.stdev(xs) / n ** 0.5


def run_once(n, backend, ipfs, seed):
    ledger = MockLedger(); ledger.bootstrap_admin("admin")
    ledger.register_identity("admin", "gw", "edge")
    storage = IPFSStorage(ipfs) if backend == "ipfs" else MemoryStorage()
    pred = HeuristicPredictor(default_scaler())
    gw = EdgeGateway("gw", ledger, storage, pred, LocalCloud(pred, AlertHub()))
    rng = np.random.default_rng(seed)
    lat_all, lat_crit = [], []
    t0 = time.perf_counter()
    for i in range(n):
        crit = i % 50 == 49
        r = np.array([40.0 if crit else 140.0, 128, 80, 76, 97, 29]) + rng.normal(0, 1, 6) * [3, 2, 1, 1, .1, 0]
        res = gw.ingest(f"P{i % 200}", float(i), r)
        (lat_crit if crit else lat_all).append(res.timings_ms["total"])
    dt = time.perf_counter() - t0
    return st.mean(lat_all), st.mean(lat_crit), n / dt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--records", type=int, default=2000)
    ap.add_argument("--reps", type=int, default=5)
    ap.add_argument("--backend", choices=["memory", "ipfs"], default="memory")
    ap.add_argument("--ipfs", default="http://127.0.0.1:5001")
    a = ap.parse_args()
    runs = [run_once(a.records, a.backend, a.ipfs, s) for s in range(a.reps)]
    for name, col in zip(("mean latency, normal (ms)", "mean latency, critical alert (ms)", "throughput (records/s)"), range(3)):
        m, h = ci95([r[col] for r in runs])
        print(f"{name:36s} {m:10.3f} +- {h:.3f}  (95% CI, R={a.reps}, N={a.records})")


if __name__ == "__main__":
    main()
