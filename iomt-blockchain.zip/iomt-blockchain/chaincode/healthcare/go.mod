module healthcare

go 1.20

require github.com/hyperledger/fabric-contract-api-go v1.2.1
