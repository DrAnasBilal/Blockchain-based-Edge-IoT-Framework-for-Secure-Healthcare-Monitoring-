// Healthcare smart contract for the Edge-IoT / Hyperledger Fabric framework.
//
// Implements (paper Sec. 3.3, 3.4, 3.8, 4.2): identity registry (ACL), patient consent grants and
// revocation, immutable anchoring of (SHA-256, IPFS CID, key id), a Private Data Collection for
// AES keys, recipient-wrapped key release (Algorithm 2), audited break-glass access, emergency
// events with clinician confirmation, and rich queries over CouchDB.
//
// Caller identity comes from the Fabric X.509 certificate attributes `uid` and `role`, e.g.
//   fabric-ca-client register --id.name dr-khan --id.secret pw --id.type client \
//       --id.attrs 'uid=dr-khan:ecert,role=physician:ecert'
// (the attributes must be requested at enrol time with --enrollment.attrs "uid,role").
//
// NOTE: written against fabric-contract-api-go v1.2.x; not compiled in the environment that
// generated this repository - run `go mod tidy && go vet ./...` first.
package main

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"log"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

const (
	pdcName          = "PDCPatientKeys"
	freshnessSeconds = 60
	breakGlassTTL    = 3600
)

type HealthcareContract struct {
	contractapi.Contract
}

type Identity struct {
	DocType string `json:"docType"`
	UID     string `json:"uid"`
	Role    string `json:"role"`
	PubKey  string `json:"pubKey,omitempty"`
}

type Grant struct {
	DocType      string `json:"docType"`
	Patient      string `json:"patient"`
	Physician    string `json:"physician"`
	ExpiresAt    int64  `json:"expiresAt"`
	Revoked      bool   `json:"revoked"`
	BreakGlass   bool   `json:"breakGlass"`
	ReviewNeeded bool   `json:"reviewNeeded"`
	Reason       string `json:"reason,omitempty"`
}

type Record struct {
	DocType string `json:"docType"`
	ID      string `json:"recordId"`
	Patient string `json:"patient"`
	SHA256  string `json:"sha256"`
	CID     string `json:"ipfsCid"`
	KeyID   string `json:"keyId"`
	TS      int64  `json:"ts"`
}

type AccessLog struct {
	DocType string `json:"docType"`
	Patient string `json:"patient"`
	Who     string `json:"who"`
	Action  string `json:"action"`
	Outcome string `json:"outcome"`
	Detail  string `json:"detail"`
	TS      int64  `json:"ts"`
}

type Emergency struct {
	DocType     string  `json:"docType"`
	ID          string  `json:"eventId"`
	Patient     string  `json:"patient"`
	Risk        float64 `json:"risk"`
	Source      string  `json:"source"`
	TS          int64   `json:"ts"`
	ConfirmedBy string  `json:"confirmedBy,omitempty"`
	ConfirmedAt int64   `json:"confirmedAt,omitempty"`
}

// KeyResponse is returned (not stored) by RequestKey. A denial is returned with a nil error so
// that the audit-log entry written by the transaction is committed.
type KeyResponse struct {
	Granted    bool   `json:"granted"`
	WrappedKey string `json:"wrappedKey,omitempty"`
	Reason     string `json:"reason,omitempty"`
}

// ---------- helpers ----------

func caller(ctx contractapi.TransactionContextInterface) (string, string, error) {
	id := ctx.GetClientIdentity()
	uid, ok, err := id.GetAttributeValue("uid")
	if err != nil || !ok {
		return "", "", fmt.Errorf("client certificate has no 'uid' attribute")
	}
	role, ok, err := id.GetAttributeValue("role")
	if err != nil || !ok {
		return "", "", fmt.Errorf("client certificate has no 'role' attribute")
	}
	return uid, role, nil
}

func requireRole(ctx contractapi.TransactionContextInterface, allowed ...string) (string, string, error) {
	uid, role, err := caller(ctx)
	if err != nil {
		return "", "", err
	}
	for _, a := range allowed {
		if role == a {
			return uid, role, nil
		}
	}
	return "", "", fmt.Errorf("role %q is not permitted for this function", role)
}

func now(ctx contractapi.TransactionContextInterface) (int64, error) {
	ts, err := ctx.GetStub().GetTxTimestamp()
	if err != nil {
		return 0, err
	}
	return ts.Seconds, nil
}

func putJSON(ctx contractapi.TransactionContextInterface, key string, v interface{}) error {
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	return ctx.GetStub().PutState(key, b)
}

func getJSON(ctx contractapi.TransactionContextInterface, key string, v interface{}) (bool, error) {
	b, err := ctx.GetStub().GetState(key)
	if err != nil {
		return false, err
	}
	if b == nil {
		return false, nil
	}
	return true, json.Unmarshal(b, v)
}

func writeLog(ctx contractapi.TransactionContextInterface, patient, who, action, outcome, detail string) error {
	t, err := now(ctx)
	if err != nil {
		return err
	}
	l := AccessLog{"accessLog", patient, who, action, outcome, detail, t}
	return putJSON(ctx, "LOG_"+ctx.GetStub().GetTxID(), l)
}

func queryDocs(ctx contractapi.TransactionContextInterface, selector string) (string, error) {
	it, err := ctx.GetStub().GetQueryResult(selector)
	if err != nil {
		return "", err
	}
	defer it.Close()
	out := []json.RawMessage{}
	for it.HasNext() {
		kv, err := it.Next()
		if err != nil {
			return "", err
		}
		out = append(out, json.RawMessage(kv.Value))
	}
	b, err := json.Marshal(out)
	return string(b), err
}

// ---------- identity & consent ----------

// RegisterIdentity: admin-only ACL entry. Physicians must supply an RSA public key (PEM).
func (c *HealthcareContract) RegisterIdentity(ctx contractapi.TransactionContextInterface, uid, role, pubKeyPEM string) error {
	if _, _, err := requireRole(ctx, "admin"); err != nil {
		return err
	}
	switch role {
	case "admin", "edge", "service", "patient", "physician":
	default:
		return fmt.Errorf("unknown role %q", role)
	}
	if role == "physician" {
		if _, err := parseRSAPublicKey(pubKeyPEM); err != nil {
			return fmt.Errorf("invalid physician public key: %v", err)
		}
	}
	return putJSON(ctx, "ID_"+uid, Identity{"identity", uid, role, pubKeyPEM})
}

// GrantAccess: only the patient themself can consent, for a bounded time.
func (c *HealthcareContract) GrantAccess(ctx contractapi.TransactionContextInterface, patientID, physicianID string, expiresAt int64) error {
	uid, _, err := requireRole(ctx, "patient")
	if err != nil {
		return err
	}
	if uid != patientID {
		return fmt.Errorf("a patient may only grant access to their own data")
	}
	var phys Identity
	if ok, err := getJSON(ctx, "ID_"+physicianID, &phys); err != nil || !ok || phys.Role != "physician" {
		return fmt.Errorf("%q is not a registered physician", physicianID)
	}
	if err := writeLog(ctx, patientID, uid, "GrantAccess", "ok", physicianID); err != nil {
		return err
	}
	return putJSON(ctx, "GRANT_"+patientID+"_"+physicianID, Grant{DocType: "grant", Patient: patientID, Physician: physicianID, ExpiresAt: expiresAt})
}

func (c *HealthcareContract) RevokeAccess(ctx contractapi.TransactionContextInterface, patientID, physicianID string) error {
	uid, _, err := requireRole(ctx, "patient")
	if err != nil {
		return err
	}
	if uid != patientID {
		return fmt.Errorf("a patient may only revoke access to their own data")
	}
	var g Grant
	if ok, err := getJSON(ctx, "GRANT_"+patientID+"_"+physicianID, &g); err != nil || !ok {
		return fmt.Errorf("no such grant")
	}
	g.Revoked = true
	if err := writeLog(ctx, patientID, uid, "RevokeAccess", "ok", physicianID); err != nil {
		return err
	}
	return putJSON(ctx, "GRANT_"+patientID+"_"+physicianID, g)
}

// ---------- anchoring & key custody ----------

// AnchorRecord stores ONLY hashes/identifiers; the encrypted payload lives in IPFS. Append-only.
func (c *HealthcareContract) AnchorRecord(ctx contractapi.TransactionContextInterface, recordID, patientID, sha256Hex, ipfsCID, keyID string) error {
	if _, _, err := requireRole(ctx, "edge"); err != nil {
		return err
	}
	if len(sha256Hex) != 64 {
		return fmt.Errorf("sha256 must be 64 hex chars")
	}
	var existing Record
	if ok, err := getJSON(ctx, "REC_"+recordID, &existing); err != nil {
		return err
	} else if ok {
		return fmt.Errorf("record %q already anchored", recordID)
	}
	t, err := now(ctx)
	if err != nil {
		return err
	}
	return putJSON(ctx, "REC_"+recordID, Record{"record", recordID, patientID, sha256Hex, ipfsCID, keyID, t})
}

// StoreKey writes the AES key (transient field "key", base64) into the private data collection.
// The plaintext key never appears in the proposal payload or on the shared ledger state.
func (c *HealthcareContract) StoreKey(ctx contractapi.TransactionContextInterface, patientID, keyID string) error {
	if _, _, err := requireRole(ctx, "edge"); err != nil {
		return err
	}
	tm, err := ctx.GetStub().GetTransient()
	if err != nil {
		return err
	}
	raw, ok := tm["key"]
	if !ok {
		return fmt.Errorf("transient field 'key' is required")
	}
	key, err := base64.StdEncoding.DecodeString(string(raw))
	if err != nil || len(key) != 32 {
		return fmt.Errorf("key must be 32 bytes (AES-256), base64-encoded")
	}
	return ctx.GetStub().PutPrivateData(pdcName, "KEY_"+patientID+"_"+keyID, key)
}

// RequestKey (Algorithm 2): authenticate -> check consent -> wrap AES key to the physician's RSA
// public key (RSA-OAEP/SHA-256) -> audit. Admins and edge nodes can never reach this path.
//
// RSA-OAEP is randomised, so with an endorsement policy requiring several endorsers their
// responses would differ; use the paper's OR(...) policy (one endorsing peer) for this function.
func (c *HealthcareContract) RequestKey(ctx contractapi.TransactionContextInterface, patientID, keyID string, clientTs int64, nonce string) (*KeyResponse, error) {
	uid, _, err := requireRole(ctx, "physician")
	if err != nil {
		return nil, err
	}
	t, err := now(ctx)
	if err != nil {
		return nil, err
	}
	deny := func(reason string) (*KeyResponse, error) {
		if err := writeLog(ctx, patientID, uid, "RequestKey", "denied", reason); err != nil {
			return nil, err
		}
		return &KeyResponse{Granted: false, Reason: reason}, nil
	}
	if d := t - clientTs; d > freshnessSeconds || d < -freshnessSeconds {
		return deny("stale timestamp")
	}
	nonceKey := "NONCE_" + uid + "_" + nonce
	if b, err := ctx.GetStub().GetState(nonceKey); err != nil {
		return nil, err
	} else if b != nil {
		return deny("replayed nonce")
	}
	if err := ctx.GetStub().PutState(nonceKey, []byte("1")); err != nil {
		return nil, err
	}
	var g Grant
	if ok, err := getJSON(ctx, "GRANT_"+patientID+"_"+uid, &g); err != nil {
		return nil, err
	} else if !ok || g.Revoked || g.ExpiresAt < t {
		return deny("no valid consent")
	}
	key, err := ctx.GetStub().GetPrivateData(pdcName, "KEY_"+patientID+"_"+keyID)
	if err != nil {
		return nil, err
	}
	if key == nil {
		return deny("unknown key")
	}
	var phys Identity
	if ok, err := getJSON(ctx, "ID_"+uid, &phys); err != nil || !ok {
		return nil, fmt.Errorf("physician not registered")
	}
	pub, err := parseRSAPublicKey(phys.PubKey)
	if err != nil {
		return nil, err
	}
	wrapped, err := rsa.EncryptOAEP(sha256.New(), rand.Reader, pub, key, nil)
	if err != nil {
		return nil, err
	}
	detail := keyID
	if g.BreakGlass {
		detail += " [break-glass]"
	}
	if err := writeLog(ctx, patientID, uid, "RequestKey", "granted", detail); err != nil {
		return nil, err
	}
	return &KeyResponse{Granted: true, WrappedKey: base64.StdEncoding.EncodeToString(wrapped)}, nil
}

// BreakGlass: time-boxed emergency override with mandatory retrospective review.
func (c *HealthcareContract) BreakGlass(ctx contractapi.TransactionContextInterface, patientID, reason string) error {
	uid, _, err := requireRole(ctx, "physician")
	if err != nil {
		return err
	}
	if len(reason) == 0 {
		return fmt.Errorf("a reason is required")
	}
	t, err := now(ctx)
	if err != nil {
		return err
	}
	if err := writeLog(ctx, patientID, uid, "BreakGlass", "granted", reason); err != nil {
		return err
	}
	return putJSON(ctx, "GRANT_"+patientID+"_"+uid, Grant{DocType: "grant", Patient: patientID, Physician: uid,
		ExpiresAt: t + breakGlassTTL, BreakGlass: true, ReviewNeeded: true, Reason: reason})
}

// ---------- emergencies ----------

func (c *HealthcareContract) RecordEmergency(ctx contractapi.TransactionContextInterface, eventID, patientID string, risk float64, source string) error {
	if _, _, err := requireRole(ctx, "edge", "service"); err != nil {
		return err
	}
	t, err := now(ctx)
	if err != nil {
		return err
	}
	return putJSON(ctx, "EM_"+eventID, Emergency{DocType: "emergency", ID: eventID, Patient: patientID, Risk: risk, Source: source, TS: t})
}

func (c *HealthcareContract) ConfirmEmergency(ctx contractapi.TransactionContextInterface, eventID string) error {
	uid, _, err := requireRole(ctx, "physician")
	if err != nil {
		return err
	}
	var e Emergency
	if ok, err := getJSON(ctx, "EM_"+eventID, &e); err != nil || !ok {
		return fmt.Errorf("unknown emergency event")
	}
	t, err := now(ctx)
	if err != nil {
		return err
	}
	e.ConfirmedBy, e.ConfirmedAt = uid, t
	return putJSON(ctx, "EM_"+eventID, e)
}

// ---------- queries (CouchDB rich queries) ----------

func (c *HealthcareContract) ListRecords(ctx contractapi.TransactionContextInterface, patientID string) (string, error) {
	return queryDocs(ctx, fmt.Sprintf(`{"selector":{"docType":"record","patient":%q}}`, patientID))
}

func (c *HealthcareContract) GetAccessLog(ctx contractapi.TransactionContextInterface, patientID string) (string, error) {
	uid, role, err := caller(ctx)
	if err != nil {
		return "", err
	}
	if role != "admin" && !(role == "patient" && uid == patientID) {
		return "", fmt.Errorf("only the patient or an auditor/admin may read the access log")
	}
	return queryDocs(ctx, fmt.Sprintf(`{"selector":{"docType":"accessLog","patient":%q}}`, patientID))
}

func (c *HealthcareContract) PendingBreakGlassReviews(ctx contractapi.TransactionContextInterface) (string, error) {
	if _, _, err := requireRole(ctx, "admin"); err != nil {
		return "", err
	}
	return queryDocs(ctx, `{"selector":{"docType":"grant","breakGlass":true,"reviewNeeded":true}}`)
}

func parseRSAPublicKey(p string) (*rsa.PublicKey, error) {
	blk, _ := pem.Decode([]byte(p))
	if blk == nil {
		return nil, fmt.Errorf("not PEM")
	}
	k, err := x509.ParsePKIXPublicKey(blk.Bytes)
	if err != nil {
		return nil, err
	}
	rk, ok := k.(*rsa.PublicKey)
	if !ok {
		return nil, fmt.Errorf("not an RSA key")
	}
	return rk, nil
}

func main() {
	cc, err := contractapi.NewChaincode(&HealthcareContract{})
	if err != nil {
		log.Panicf("create chaincode: %v", err)
	}
	if err := cc.Start(); err != nil {
		log.Panicf("start chaincode: %v", err)
	}
}
