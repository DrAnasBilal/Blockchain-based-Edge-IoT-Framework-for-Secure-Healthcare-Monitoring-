"""Evaluation metrics, calibration (ECE), threshold selection and bootstrap CIs (Sec. 3.9.4, 5.2)."""
from __future__ import annotations

import numpy as np
from sklearn.metrics import average_precision_score, roc_auc_score


def confusion(y, pred):
    y, pred = np.asarray(y), np.asarray(pred)
    return (int(((y == 1) & (pred == 1)).sum()), int(((y == 1) & (pred == 0)).sum()),
            int(((y == 0) & (pred == 1)).sum()), int(((y == 0) & (pred == 0)).sum()))  # TP FN FP TN


def ece(y, p, bins: int = 10) -> float:
    y, p = np.asarray(y), np.asarray(p)
    edges = np.linspace(0, 1, bins + 1)
    total = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (p >= lo) & ((p < hi) if hi < 1 else (p <= hi))
        if m.any():
            total += m.mean() * abs(y[m].mean() - p[m].mean())
    return float(total)


def compute_metrics(y, p, tau: float) -> dict:
    y, p = np.asarray(y), np.asarray(p)
    pred = (p >= tau).astype(int)
    tp, fn, fp, tn = confusion(y, pred)
    sens = tp / max(tp + fn, 1)
    spec = tn / max(tn + fp, 1)
    prec = tp / max(tp + fp, 1)
    f1 = 2 * prec * sens / max(prec + sens, 1e-12)
    out = {"sensitivity": sens, "specificity": spec, "precision": prec, "f1": f1,
           "accuracy": (tp + tn) / len(y), "ece": ece(y, p), "tp": tp, "fn": fn, "fp": fp, "tn": tn}
    if 0 < y.sum() < len(y):
        out["auroc"] = float(roc_auc_score(y, p))
        out["auprc"] = float(average_precision_score(y, p))
    return out


def select_threshold(y, p) -> float:
    """Maximise Youden's J (ties broken by F1) on the VALIDATION split only."""
    best = (-1.0, -1.0, 0.5)
    for tau in np.linspace(0.05, 0.95, 91):
        m = compute_metrics(y, p, tau)
        key = (m["sensitivity"] + m["specificity"] - 1, m["f1"])
        if key > best[:2]:
            best = (key[0], key[1], float(tau))
    return best[2]


def bootstrap_ci(y, p, tau: float, n_boot: int = 1000, seed: int = 0, alpha: float = 0.05) -> dict:
    rng = np.random.default_rng(seed)
    y, p = np.asarray(y), np.asarray(p)
    keys, rows = None, []
    for _ in range(n_boot):
        i = rng.integers(0, len(y), len(y))
        m = compute_metrics(y[i], p[i], tau)
        keys = keys or [k for k in m if k not in ("tp", "fn", "fp", "tn")]
        rows.append([m.get(k, np.nan) for k in keys])
    arr = np.array(rows)
    lo, hi = np.nanpercentile(arr, [100 * alpha / 2, 100 * (1 - alpha / 2)], axis=0)
    return {k: (float(l), float(h)) for k, l, h in zip(keys, lo, hi)}
