"""AES-256-GCM encryption, SHA-256 content hashing, key rotation and key wrapping.

Maps to paper Sec. 3.8 (harmonised cryptographic specification) and Algorithm 4.
"""
from __future__ import annotations

import base64
import os
import secrets
import struct
import threading
import time
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Callable, Optional

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from . import config as C

NONCE_LEN = 12   # 96-bit nonce
TAG_LEN = 16     # 128-bit GCM tag (appended to ciphertext by AESGCM)
KEY_LEN = 32     # AES-256


class NonceReuseError(RuntimeError):
    pass


class NonceGenerator:
    """96-bit nonce = 32-bit CSPRNG prefix (fresh per key) || 64-bit state-tracked counter.

    Uniqueness under one key is guaranteed by the counter; the random prefix protects
    against counter-state loss after an edge reboot.
    """

    def __init__(self) -> None:
        self._prefix = os.urandom(4)
        self._counter = 0
        self._lock = threading.Lock()

    def next(self) -> bytes:
        with self._lock:
            if self._counter >= 2**64 - 1:
                raise NonceReuseError("nonce space exhausted; rotate the key")
            n = self._prefix + struct.pack(">Q", self._counter)
            self._counter += 1
            return n


def sha256_hex(data: bytes) -> str:
    return sha256(data).hexdigest()


def encrypt(key: bytes, plaintext: bytes, aad: bytes, nonce: bytes) -> bytes:
    """Return nonce || ciphertext || tag."""
    return nonce + AESGCM(key).encrypt(nonce, plaintext, aad)


def decrypt(key: bytes, blob: bytes, aad: bytes) -> bytes:
    """Raises cryptography.exceptions.InvalidTag if the blob or AAD was modified."""
    nonce, ct = blob[:NONCE_LEN], blob[NONCE_LEN:]
    return AESGCM(key).decrypt(nonce, ct, aad)


@dataclass
class KeyRecord:
    key_id: str
    key: bytes
    created_at: float
    uses: int = 0
    retired_at: Optional[float] = None
    nonces: NonceGenerator = field(default_factory=NonceGenerator)


@dataclass
class EncryptedBlob:
    blob: bytes
    key_id: str
    sha256: str  # content hash anchored on the ledger (paper's "CID_i = SHA-256(C_i)")


class KeyManager:
    """Per-subject symmetric key lifecycle: rotate every 24 h or 10,000 encryptions.

    Retired keys are retained (callers should persist them in the Fabric private data
    collection) so authorised physicians can still decrypt historical records.
    """

    def __init__(self, rotate_after_s: float = C.KEY_ROTATE_SECONDS,
                 rotate_after_tx: int = C.KEY_ROTATE_TX,
                 clock: Callable[[], float] = time.time,
                 on_new_key: Optional[Callable[[KeyRecord], None]] = None) -> None:
        self.rotate_after_s = rotate_after_s
        self.rotate_after_tx = rotate_after_tx
        self.clock = clock
        self.on_new_key = on_new_key
        self._keys: dict[str, KeyRecord] = {}
        self._current: Optional[KeyRecord] = None
        self._epoch = 0

    def _rotate(self) -> KeyRecord:
        now = self.clock()
        if self._current is not None:
            self._current.retired_at = now
        self._epoch += 1
        rec = KeyRecord(key_id=f"k{self._epoch}-{secrets.token_hex(4)}",
                        key=AESGCM.generate_key(bit_length=256), created_at=now)
        self._keys[rec.key_id] = rec
        self._current = rec
        if self.on_new_key:
            self.on_new_key(rec)
        return rec

    def current(self) -> KeyRecord:
        c = self._current
        if (c is None or self.clock() - c.created_at >= self.rotate_after_s
                or c.uses >= self.rotate_after_tx):
            c = self._rotate()
        return c

    def get_key(self, key_id: str) -> bytes:
        return self._keys[key_id].key

    def encrypt(self, plaintext: bytes, aad: bytes = b"") -> EncryptedBlob:
        rec = self.current()
        rec.uses += 1
        blob = encrypt(rec.key, plaintext, aad, rec.nonces.next())
        return EncryptedBlob(blob=blob, key_id=rec.key_id, sha256=sha256_hex(blob))


# ----- asymmetric key wrapping (recipient-specific, Algorithm 2) -----

def generate_rsa_keypair(bits: int = 2048) -> tuple[bytes, bytes]:
    priv = rsa.generate_private_key(public_exponent=65537, key_size=bits)
    priv_pem = priv.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                  serialization.NoEncryption())
    pub_pem = priv.public_key().public_bytes(serialization.Encoding.PEM,
                                             serialization.PublicFormat.SubjectPublicKeyInfo)
    return priv_pem, pub_pem


def _oaep():
    return padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)


def wrap_key(pub_pem: bytes, key: bytes) -> str:
    pub = serialization.load_pem_public_key(pub_pem)
    return base64.b64encode(pub.encrypt(key, _oaep())).decode()


def unwrap_key(priv_pem: bytes, wrapped_b64: str) -> bytes:
    priv = serialization.load_pem_private_key(priv_pem, password=None)
    return priv.decrypt(base64.b64decode(wrapped_b64), _oaep())
