"""Hybrid CNN-LSTM (paper Sec. 3.5, 3.6.1, Table 2, Table 5) with the edge/cloud split.

EdgeCNN   (Raspberry Pi): 6x6 grid -> Conv3x3(64) -> Conv3x3(128) -> MaxPool2x2 -> 1152-d vector
CloudLSTM (server)      : sequence of T vectors -> LSTM(128) -> FC(64)+Dropout(0.3) -> 2-way softmax

Note: Table 2 of the paper lists inconsistent input sizes for layers 7-8 (FC takes 128 from the
LSTM, output layer takes 64). The only consistent reading is LSTM(128) -> FC(64) -> softmax(2),
which is what is implemented here.
"""
from __future__ import annotations

import torch
import torch.nn as nn

from . import config as C


class EdgeCNN(nn.Module):
    out_dim = 128 * (C.GRID // 2) ** 2  # 1152

    def __init__(self, c1: int = 64, c2: int = 128) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, c1, 3, padding=1), nn.ReLU(),
            nn.Conv2d(c1, c2, 3, padding=1), nn.ReLU(),
            nn.MaxPool2d(2),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B,1,6,6) -> (B,1152)
        return self.net(x).flatten(1)


class CloudLSTM(nn.Module):
    def __init__(self, in_dim: int = EdgeCNN.out_dim, hidden: int = 128, fc: int = 64, dropout: float = 0.3) -> None:
        super().__init__()
        self.lstm = nn.LSTM(in_dim, hidden, batch_first=True)
        self.head = nn.Sequential(nn.Linear(hidden, fc), nn.ReLU(), nn.Dropout(dropout), nn.Linear(fc, 2))

    def forward(self, feats: torch.Tensor) -> torch.Tensor:  # (B,T,1152) -> logits (B,2)
        out, _ = self.lstm(feats)
        return self.head(out[:, -1])


class HybridCNNLSTM(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.edge = EdgeCNN()
        self.cloud = CloudLSTM()

    def forward(self, x: torch.Tensor) -> torch.Tensor:  # (B,T,1,6,6) -> logits
        b, t = x.shape[:2]
        f = self.edge(x.reshape(b * t, *x.shape[2:])).reshape(b, t, -1)
        return self.cloud(f)

    @torch.no_grad()
    def predict_proba(self, x: torch.Tensor) -> torch.Tensor:
        return torch.softmax(self.forward(x), dim=-1)[:, 1]
