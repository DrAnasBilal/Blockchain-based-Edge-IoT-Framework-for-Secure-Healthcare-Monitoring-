"""How the edge gateway talks to the cloud tier: HTTP(S/mTLS) or in-process."""
from __future__ import annotations

import numpy as np
import requests

from .alerts import AlertHub


class LocalCloud:
    """In-process cloud tier (demo / tests)."""

    def __init__(self, predictor, hub: AlertHub) -> None:
        self.predictor, self.hub = predictor, hub

    def infer(self, patient_id: str, feats: np.ndarray) -> float:
        return self.predictor.cloud_predict(feats)

    def alert(self, payload: dict) -> str:
        return self.hub.dispatch(payload)


class HttpCloud:
    def __init__(self, base_url: str, cert: tuple[str, str] | None = None, verify: str | bool = True,
                 timeout: float = 2.0) -> None:
        self.base, self.cert, self.verify, self.timeout = base_url.rstrip("/"), cert, verify, timeout

    def _post(self, path: str, body: dict) -> dict:
        r = requests.post(self.base + path, json=body, cert=self.cert, verify=self.verify, timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    def infer(self, patient_id: str, feats: np.ndarray) -> float:
        return float(self._post("/v1/infer", {"patient_id": patient_id, "features": feats.tolist()})["risk"])

    def alert(self, payload: dict) -> str:
        return self._post("/v1/alerts", payload)["alert_id"]
