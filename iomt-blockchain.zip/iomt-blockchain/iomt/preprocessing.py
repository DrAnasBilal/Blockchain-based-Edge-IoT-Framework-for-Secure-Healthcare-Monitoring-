"""Edge preprocessing (paper Sec. 3.2 and 3.9.3): aggregation, causal Kalman filtering,
min-max normalisation (fit on the training split only) and 6x6 grid construction."""
from __future__ import annotations

import numpy as np

from . import config as C

# Per-feature (process variance, measurement variance) in raw units.
DEFAULT_Q = np.array([4.0, 4.0, 2.0, 4.0, 0.1, 1e-4])
DEFAULT_R = np.array([25.0, 16.0, 9.0, 9.0, 1.0, 1e-2])


class CausalKalman:
    """Scalar random-walk Kalman filter per feature, forward-only (no look-ahead).

    NaN measurements (dropped packets) skip the update step, so the estimate simply
    carries forward - this keeps the filter causal, unlike offline interpolation.
    """

    def __init__(self, q: np.ndarray = DEFAULT_Q, r: np.ndarray = DEFAULT_R) -> None:
        self.q, self.r = np.asarray(q, float), np.asarray(r, float)
        self.x: np.ndarray | None = None
        self.p = np.ones_like(self.q) * 10.0

    def update(self, z: np.ndarray) -> np.ndarray:
        z = np.asarray(z, float)
        if self.x is None:
            self.x = np.where(np.isnan(z), 0.0, z)
            return self.x.copy()
        p_pred = self.p + self.q
        k = p_pred / (p_pred + self.r)
        upd = ~np.isnan(z)
        self.x = np.where(upd, self.x + k * (np.nan_to_num(z) - self.x), self.x)
        self.p = np.where(upd, (1 - k) * p_pred, p_pred)
        return self.x.copy()

    def filter_series(self, arr: np.ndarray) -> np.ndarray:
        return np.stack([self.update(row) for row in arr])


class MinMaxScaler:
    """Scale each feature to [0, 1]. Fit ONLY on training-patient data (Sec. 3.9.3)."""

    def __init__(self) -> None:
        self.lo: np.ndarray | None = None
        self.hi: np.ndarray | None = None

    def fit(self, arr: np.ndarray) -> "MinMaxScaler":
        self.lo, self.hi = arr.min(axis=0), arr.max(axis=0)
        self.hi = np.where(self.hi - self.lo < 1e-9, self.lo + 1.0, self.hi)
        return self

    def transform(self, arr: np.ndarray) -> np.ndarray:
        return (arr - self.lo) / (self.hi - self.lo)

    def inverse(self, arr: np.ndarray) -> np.ndarray:
        return arr * (self.hi - self.lo) + self.lo

    def to_dict(self) -> dict:
        return {"lo": self.lo.tolist(), "hi": self.hi.tolist()}

    @classmethod
    def from_dict(cls, d: dict) -> "MinMaxScaler":
        s = cls()
        s.lo, s.hi = np.array(d["lo"], float), np.array(d["hi"], float)
        return s


def aggregate_packet(values: np.ndarray, timestamps: np.ndarray, quality: np.ndarray,
                     tau_s: float = 300.0) -> np.ndarray:
    """Weighted average of k readings (k, F): weight = quality * exp(-age / tau) (Sec. 3.2)."""
    age = timestamps.max() - timestamps
    w = quality * np.exp(-age / tau_s)
    return (values * w[:, None]).sum(axis=0) / w.sum()


def interpolate_missing(arr: np.ndarray) -> np.ndarray:
    """Offline linear interpolation of NaNs (used for dataset preparation only)."""
    out = arr.copy()
    idx = np.arange(len(out))
    for j in range(out.shape[1]):
        m = np.isnan(out[:, j])
        if m.any() and (~m).any():
            out[m, j] = np.interp(idx[m], idx[~m], out[~m, j])
    return out


def to_grid(window: np.ndarray) -> np.ndarray:
    """(6 time steps, 6 features) -> (1, 6, 6) channel-first grid for the CNN."""
    assert window.shape == (C.GRID, C.N_FEATURES), window.shape
    return window[None, :, :].astype(np.float32)
