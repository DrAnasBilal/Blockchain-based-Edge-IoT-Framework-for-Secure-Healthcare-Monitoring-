"""Ledger abstraction with two backends.

  MockLedger      - pure-Python, hash-chained re-implementation of the chaincode semantics
                    (ACL, grants/revocation, anchoring, private key collection, break-glass,
                    audit log, emergency events). Used by tests, demo and benchmarks.
  FabricCLILedger - invokes the Go chaincode in chaincode/healthcare through the `peer` CLI.

`caller` mirrors the authenticated Fabric client identity (X.509 `uid` attribute).
"""
from __future__ import annotations

import base64
import json
import os
import subprocess
import threading
import time
from dataclasses import asdict, dataclass, field
from hashlib import sha256
from typing import Callable, Optional

from . import config as C
from .crypto import wrap_key


class LedgerError(Exception):
    pass


@dataclass
class KeyResponse:
    granted: bool
    wrapped_key: str = ""
    reason: str = ""


class MockLedger:
    ROLES = {"admin", "edge", "service", "patient", "physician"}

    def __init__(self, clock: Callable[[], float] = time.time) -> None:
        self.clock = clock
        self._lock = threading.Lock()
        self.identities: dict[str, dict] = {}
        self.grants: dict[tuple, dict] = {}
        self.records: dict[str, dict] = {}
        self.access_log: list[dict] = []
        self.emergencies: dict[str, dict] = {}
        self._pdc: dict[tuple, bytes] = {}           # private data collection (off the chain)
        self._nonces: set[tuple] = set()
        self.chain: list[dict] = [{"index": 0, "prev": "0" * 64, "hash": sha256(b"genesis").hexdigest(), "tx": "genesis"}]

    # ---------- helpers ----------
    def _commit(self, fn: str, caller: str, payload: dict) -> None:
        body = json.dumps({"fn": fn, "caller": caller, "ts": self.clock(), "payload": payload}, sort_keys=True)
        prev = self.chain[-1]["hash"]
        self.chain.append({"index": len(self.chain), "prev": prev,
                           "hash": sha256((prev + body).encode()).hexdigest(), "tx": body})

    def verify_chain(self) -> bool:
        for i in range(1, len(self.chain)):
            b, p = self.chain[i], self.chain[i - 1]
            if b["prev"] != p["hash"] or b["hash"] != sha256((p["hash"] + b["tx"]).encode()).hexdigest():
                return False
        return True

    def _role(self, caller: str, *allowed: str) -> dict:
        ident = self.identities.get(caller)
        if ident is None:
            raise LedgerError(f"unregistered identity '{caller}'")
        if ident["role"] not in allowed:
            raise LedgerError(f"role '{ident['role']}' not permitted (need {allowed})")
        return ident

    def _log(self, patient: str, who: str, action: str, outcome: str, detail: str = "") -> None:
        entry = {"patient": patient, "who": who, "action": action, "outcome": outcome,
                 "detail": detail, "ts": self.clock()}
        self.access_log.append(entry)
        self._commit("log", who, entry)

    def bootstrap_admin(self, uid: str) -> None:
        """Stand-in for the Fabric CA enrolling the first admin."""
        self.identities[uid] = {"role": "admin", "pubkey": None}

    # ---------- identity & consent ----------
    def register_identity(self, caller: str, uid: str, role: str, pubkey_pem: Optional[bytes] = None) -> None:
        with self._lock:
            self._role(caller, "admin")
            if role not in self.ROLES:
                raise LedgerError("unknown role")
            if role == "physician" and not pubkey_pem:
                raise LedgerError("physician needs a public key")
            self.identities[uid] = {"role": role, "pubkey": pubkey_pem}
            self._commit("RegisterIdentity", caller, {"uid": uid, "role": role})

    def grant_access(self, caller: str, patient_id: str, physician_id: str, expires_at: float) -> None:
        with self._lock:
            self._role(caller, "patient")
            if caller != patient_id:
                raise LedgerError("only the patient can grant access to their data")
            self._role(physician_id, "physician")
            self.grants[(patient_id, physician_id)] = {"expires_at": expires_at, "revoked": False, "break_glass": False}
            self._commit("GrantAccess", caller, {"patient": patient_id, "physician": physician_id, "exp": expires_at})

    def revoke_access(self, caller: str, patient_id: str, physician_id: str) -> None:
        with self._lock:
            self._role(caller, "patient")
            if caller != patient_id:
                raise LedgerError("only the patient can revoke access")
            g = self.grants.get((patient_id, physician_id))
            if g:
                g["revoked"] = True
            self._commit("RevokeAccess", caller, {"patient": patient_id, "physician": physician_id})

    # ---------- anchoring & keys ----------
    def anchor_record(self, caller: str, record_id: str, patient_id: str, sha256_hex: str,
                      ipfs_cid: str, key_id: str) -> None:
        with self._lock:
            self._role(caller, "edge")
            if record_id in self.records:
                raise LedgerError("record already anchored (ledger is append-only)")
            self.records[record_id] = {"record_id": record_id, "patient": patient_id, "sha256": sha256_hex,
                                       "ipfs_cid": ipfs_cid, "key_id": key_id, "ts": self.clock()}
            self._commit("AnchorRecord", caller, self.records[record_id])

    def store_key(self, caller: str, patient_id: str, key_id: str, key: bytes) -> None:
        with self._lock:
            self._role(caller, "edge")
            self._pdc[(patient_id, key_id)] = key
            # Only a hash of the private data lands on the shared chain (as in Fabric PDCs).
            self._commit("StoreKey", caller, {"patient": patient_id, "key_id": key_id,
                                              "key_hash": sha256(key).hexdigest()})

    def list_records(self, patient_id: str) -> list[dict]:
        return [r for r in self.records.values() if r["patient"] == patient_id]

    def get_record(self, record_id: str) -> dict:
        return self.records[record_id]

    def request_key(self, caller: str, patient_id: str, key_id: str, ts: float, nonce: str) -> KeyResponse:
        """Algorithm 2: authorise, then release the AES key wrapped to the caller's public key."""
        with self._lock:
            ident = self._role(caller, "physician")     # admins / edge nodes can never read keys
            now = self.clock()
            if abs(now - ts) > C.REQUEST_FRESHNESS_S:
                self._log(patient_id, caller, "RequestKey", "denied", "stale timestamp")
                return KeyResponse(False, reason="stale timestamp")
            if (caller, nonce) in self._nonces:
                self._log(patient_id, caller, "RequestKey", "denied", "replayed nonce")
                return KeyResponse(False, reason="replayed nonce")
            self._nonces.add((caller, nonce))
            g = self.grants.get((patient_id, caller))
            if not g or g["revoked"] or g["expires_at"] < now:
                self._log(patient_id, caller, "RequestKey", "denied", "no valid consent")
                return KeyResponse(False, reason="no valid consent")
            key = self._pdc.get((patient_id, key_id))
            if key is None:
                self._log(patient_id, caller, "RequestKey", "denied", "unknown key")
                return KeyResponse(False, reason="unknown key")
            wrapped = wrap_key(ident["pubkey"], key)
            self._log(patient_id, caller, "RequestKey", "granted", key_id + (" [break-glass]" if g["break_glass"] else ""))
            return KeyResponse(True, wrapped_key=wrapped)

    def break_glass(self, caller: str, patient_id: str, reason: str) -> None:
        with self._lock:
            self._role(caller, "physician")
            if not reason.strip():
                raise LedgerError("break-glass requires a reason")
            self.grants[(patient_id, caller)] = {"expires_at": self.clock() + C.BREAK_GLASS_TTL_S,
                                                 "revoked": False, "break_glass": True, "review_pending": True,
                                                 "reason": reason}
            self._log(patient_id, caller, "BreakGlass", "granted", reason)

    def pending_reviews(self) -> list[tuple]:
        return [k for k, g in self.grants.items() if g.get("review_pending")]

    # ---------- emergencies ----------
    def record_emergency(self, caller: str, event_id: str, patient_id: str, risk: float, source: str) -> None:
        with self._lock:
            self._role(caller, "edge", "service")
            self.emergencies[event_id] = {"patient": patient_id, "risk": risk, "source": source,
                                          "ts": self.clock(), "confirmed_by": None}
            self._commit("RecordEmergency", caller, {"id": event_id, **self.emergencies[event_id]})

    def confirm_emergency(self, caller: str, event_id: str) -> None:
        with self._lock:
            self._role(caller, "physician")
            ev = self.emergencies[event_id]
            ev["confirmed_by"], ev["confirmed_at"] = caller, self.clock()
            self._commit("ConfirmEmergency", caller, {"id": event_id})

    def get_access_log(self, patient_id: str) -> list[dict]:
        return [e for e in self.access_log if e["patient"] == patient_id]


class FabricCLILedger:
    """Thin wrapper around the `peer` CLI (works with fabric-samples/test-network).

    The Fabric identity is chosen by the environment you pass (CORE_PEER_LOCALMSPID,
    CORE_PEER_MSPCONFIGPATH, ...), so `caller` arguments are accepted but ignored: use one
    FabricCLILedger instance per identity (edge gateway, patient app, physician app).
    """

    def __init__(self, env: dict, orderer: str = "localhost:7050",
                 orderer_host: str = "orderer.example.com", orderer_ca: str = "",
                 peers: Optional[list[tuple[str, str]]] = None) -> None:
        self.env = {**os.environ, **env}
        self.orderer, self.orderer_host, self.orderer_ca = orderer, orderer_host, orderer_ca
        self.peers = peers or []  # [(address, tls_root_cert), ...]

    def _peer(self, args: list[str]) -> str:
        r = subprocess.run(["peer", *args], env=self.env, capture_output=True, text=True, timeout=30)
        if r.returncode != 0:
            raise LedgerError(r.stderr.strip()[-500:])
        return r.stdout + r.stderr

    def _invoke(self, fn: str, *args: str, transient: Optional[dict] = None) -> str:
        cmd = ["chaincode", "invoke", "-o", self.orderer, "--ordererTLSHostnameOverride", self.orderer_host,
               "--tls", "--cafile", self.orderer_ca, "-C", C.CHANNEL, "-n", C.CHAINCODE, "--waitForEvent",
               "-c", json.dumps({"function": fn, "Args": list(args)})]
        for addr, ca in self.peers:
            cmd += ["--peerAddresses", addr, "--tlsRootCertFiles", ca]
        if transient:
            cmd += ["--transient", json.dumps({k: base64.b64encode(v).decode() for k, v in transient.items()})]
        return self._peer(cmd)

    def _query(self, fn: str, *args: str) -> str:
        return self._peer(["chaincode", "query", "-C", C.CHANNEL, "-n", C.CHAINCODE,
                           "-c", json.dumps({"function": fn, "Args": list(args)})]).strip()

    def register_identity(self, caller, uid, role, pubkey_pem=None):
        self._invoke("RegisterIdentity", uid, role, (pubkey_pem or b"").decode())

    def grant_access(self, caller, patient_id, physician_id, expires_at):
        self._invoke("GrantAccess", patient_id, physician_id, str(int(expires_at)))

    def revoke_access(self, caller, patient_id, physician_id):
        self._invoke("RevokeAccess", patient_id, physician_id)

    def anchor_record(self, caller, record_id, patient_id, sha256_hex, ipfs_cid, key_id):
        self._invoke("AnchorRecord", record_id, patient_id, sha256_hex, ipfs_cid, key_id)

    def store_key(self, caller, patient_id, key_id, key: bytes):
        self._invoke("StoreKey", patient_id, key_id, transient={"key": key})

    def request_key(self, caller, patient_id, key_id, ts, nonce) -> KeyResponse:
        out = self._invoke("RequestKey", patient_id, key_id, str(int(ts)), nonce)
        # `peer` prints 'payload:"{...}"' on success; extract the JSON payload.
        start, end = out.find("{"), out.rfind("}")
        d = json.loads(out[start:end + 1].replace('\\"', '"'))
        return KeyResponse(d["granted"], d.get("wrappedKey", ""), d.get("reason", ""))

    def break_glass(self, caller, patient_id, reason):
        self._invoke("BreakGlass", patient_id, reason)

    def record_emergency(self, caller, event_id, patient_id, risk, source):
        self._invoke("RecordEmergency", event_id, patient_id, f"{risk:.4f}", source)

    def confirm_emergency(self, caller, event_id):
        self._invoke("ConfirmEmergency", event_id)

    def list_records(self, patient_id):
        return json.loads(self._query("ListRecords", patient_id) or "[]")

    def get_access_log(self, patient_id):
        return json.loads(self._query("GetAccessLog", patient_id) or "[]")
