"""Emergency alert hub: low-latency dispatch, clinician confirmation, timeout monitor and the
system fallback path (paper Fig. 3, abstract). Transport-agnostic: the FastAPI server wires
subscribers to WebSockets; tests wire them to plain lists."""
from __future__ import annotations

import itertools
import threading
import time
from dataclasses import dataclass
from typing import Callable

Subscriber = Callable[[dict], None]


@dataclass
class _Pending:
    alert: dict
    t0: float
    escalated: bool = False


class AlertHub:
    def __init__(self, confirm_timeout_s: float = 30.0, clock: Callable[[], float] = time.monotonic,
                 on_escalate: Callable[[dict], None] | None = None) -> None:
        self.timeout, self.clock, self.on_escalate = confirm_timeout_s, clock, on_escalate
        self._subs: dict[str, list[Subscriber]] = {"primary": [], "fallback": []}
        self.pending: dict[str, _Pending] = {}
        self.confirmed: dict[str, str] = {}
        self._ids = itertools.count(1)
        self._lock = threading.Lock()

    def subscribe(self, cb: Subscriber, channel: str = "primary") -> Callable[[], None]:
        self._subs[channel].append(cb)
        return lambda: self._subs[channel].remove(cb)

    def dispatch(self, alert: dict) -> str:
        with self._lock:
            aid = f"EM-{next(self._ids):06d}"
            alert = {**alert, "alert_id": aid, "type": "emergency"}
            self.pending[aid] = _Pending(alert, self.clock())
        for cb in list(self._subs["primary"]):
            cb(alert)
        return aid

    def confirm(self, alert_id: str, clinician_id: str) -> bool:
        with self._lock:
            if alert_id not in self.pending:
                return False
            self.pending.pop(alert_id)
            self.confirmed[alert_id] = clinician_id
            return True

    def check_timeouts(self) -> list[str]:
        """Escalate unconfirmed alerts to the fallback channel. Call periodically."""
        now, out = self.clock(), []
        with self._lock:
            due = [(k, p) for k, p in self.pending.items() if not p.escalated and now - p.t0 >= self.timeout]
            for _, p in due:
                p.escalated = True
        for aid, p in due:
            msg = {**p.alert, "type": "fallback_escalation", "unconfirmed_for_s": now - p.t0}
            for cb in list(self._subs["fallback"]):
                cb(msg)
            if self.on_escalate:
                self.on_escalate(msg)
            out.append(aid)
        return out
