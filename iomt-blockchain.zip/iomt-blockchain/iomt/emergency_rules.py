"""Threshold-based clinical emergency rules (paper Sec. 4.1).

These rules serve two purposes:
  1. They generate the ground-truth labels for training (y_t = 1 if a threshold is
     crossed inside the next 60 minutes).
  2. They are the *emergency fallback route* at the edge: a critical reading raises an
     alert immediately, even if the cloud LSTM is unreachable.
"""
from __future__ import annotations

import numpy as np

from . import config as C


def emergency_mask(arr: np.ndarray) -> np.ndarray:
    """arr: (n, 6) raw readings in config.FEATURES order -> boolean (n,)."""
    arr = np.atleast_2d(arr)
    g, sbp, dbp, hr, spo2 = (arr[:, C.IDX[k]] for k in ("glucose", "systolic", "diastolic", "pulse", "spo2"))
    return (
        (g < C.GLUCOSE_LOW) | (g > C.GLUCOSE_HIGH)
        | (sbp > C.SYSTOLIC_CRISIS) | (dbp > C.DIASTOLIC_CRISIS)
        | (hr < C.PULSE_LOW) | (hr > C.PULSE_HIGH)
        | (spo2 < C.SPO2_LOW)
    )


def emergency_reasons(row: np.ndarray) -> list[str]:
    """Human-readable reasons for a single raw reading (empty list = stable)."""
    r = {k: float(row[C.IDX[k]]) for k in C.FEATURES}
    out = []
    if r["glucose"] < C.GLUCOSE_LOW:
        out.append("severe_hypoglycemia")
    if r["glucose"] > C.GLUCOSE_HIGH:
        out.append("severe_hyperglycemia")
    if r["systolic"] > C.SYSTOLIC_CRISIS or r["diastolic"] > C.DIASTOLIC_CRISIS:
        out.append("hypertensive_crisis")
    if r["pulse"] < C.PULSE_LOW:
        out.append("bradycardia")
    if r["pulse"] > C.PULSE_HIGH:
        out.append("tachycardia")
    if r["spo2"] < C.SPO2_LOW:
        out.append("hypoxemia")
    return out


def future_labels(flags: np.ndarray, horizon: int) -> np.ndarray:
    """y[t] = 1 if flags[t+1 .. t+horizon] contains any True (rolling-horizon label)."""
    n = len(flags)
    c = np.concatenate([[0], np.cumsum(flags.astype(np.int64))])
    y = np.zeros(n, dtype=np.int64)
    for t in range(n):
        lo, hi = t + 1, min(n, t + 1 + horizon)
        if hi > lo:
            y[t] = int(c[hi] - c[lo] > 0)
    return y
