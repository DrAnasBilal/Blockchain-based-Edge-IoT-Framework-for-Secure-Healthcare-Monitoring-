"""Dataset construction: synthetic multivariate trajectories, optional DiaBD-seeded
trajectories, patient-wise splits and leakage-free windowing (paper Sec. 3.6, 3.9).

IMPORTANT: DiaBD (and PIMA) are cross-sectional tables - one row per person. The paper's
time-series evaluation therefore requires *simulated* trajectories. `trajectories_from_diabd`
uses each real record only as the baseline of a simulated 15-minute series.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from numpy.lib.stride_tricks import sliding_window_view

from . import config as C
from .emergency_rules import emergency_mask, future_labels
from .preprocessing import CausalKalman, MinMaxScaler

EPISODES = ("hypo", "hyper", "crisis", "hypoxia", "tachy")


def _ar1(rng, n, mean, sd, phi=0.97):
    x = np.empty(n)
    x[0] = mean + rng.normal(0, sd)
    for t in range(1, n):
        x[t] = mean + phi * (x[t - 1] - mean) + rng.normal(0, sd * np.sqrt(1 - phi**2))
    return x


def synth_patient(rng: np.random.Generator, n_steps: int = 288, episodes: int = 8,
                  baseline: dict | None = None) -> np.ndarray:
    """One patient trajectory (n_steps, 6) with pre-emergency ramps so risk is predictable."""
    b = baseline or {}
    g0 = b.get("glucose", rng.normal(150, 30))
    s0 = b.get("systolic", rng.normal(130, 12))
    d0 = b.get("diastolic", 0.6 * s0 + rng.normal(0, 4))
    p0 = b.get("pulse", rng.normal(78, 8))
    o0 = b.get("spo2", np.clip(rng.normal(96.5, 1.0), 93, 99))
    bmi = b.get("bmi", rng.normal(29, 4))
    x = np.stack([
        _ar1(rng, n_steps, np.clip(g0, 90, 240), 12),
        _ar1(rng, n_steps, np.clip(s0, 100, 160), 6),
        _ar1(rng, n_steps, np.clip(d0, 60, 100), 4),
        _ar1(rng, n_steps, np.clip(p0, 55, 110), 4),
        _ar1(rng, n_steps, o0, 0.5),
        np.full(n_steps, bmi),
    ], axis=1)
    ramp, hold = 6, 3
    spacing = ramp + hold + 4
    starts = rng.choice(np.arange(8, n_steps - spacing, spacing), size=min(episodes, (n_steps - 16) // spacing),
                        replace=False)
    for s in starts:
        kind = rng.choice(EPISODES)
        col, target = {"hypo": ("glucose", rng.uniform(38, 52)), "hyper": ("glucose", rng.uniform(360, 420)),
                       "crisis": ("systolic", rng.uniform(185, 205)), "hypoxia": ("spo2", rng.uniform(82, 88.5)),
                       "tachy": ("pulse", rng.uniform(155, 175))}[kind]
        j = C.IDX[col]
        start_val = x[s, j]
        x[s:s + ramp, j] = np.linspace(start_val, target, ramp) + rng.normal(0, 1, ramp)
        x[s + ramp:s + ramp + hold, j] = target + rng.normal(0, 1, hold)
        if kind == "crisis":
            x[s + ramp:s + ramp + hold, C.IDX["diastolic"]] += 20
    x += rng.normal(0, 1, x.shape) * np.array([3, 2, 1.5, 1.5, 0.2, 0.0])  # sensor noise
    return x


def synthetic_cohort(n_patients: int, n_steps: int = 288, episodes: int = 8, seed: int = 42) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    return {f"P{i:05d}": synth_patient(rng, n_steps, episodes) for i in range(n_patients)}


def _find_col(df: pd.DataFrame, *cands: str) -> str | None:
    norm = {c.lower().replace(" ", "").replace("_", ""): c for c in df.columns}
    for cand in cands:
        k = cand.lower().replace(" ", "").replace("_", "")
        for nk, orig in norm.items():
            if k in nk:
                return orig
    return None


def trajectories_from_diabd(csv_path: str, n_steps: int = 288, episodes: int = 8, seed: int = 42,
                            max_patients: int | None = None) -> dict[str, np.ndarray]:
    """Seed simulated trajectories from DiaBD baselines. Column names are matched fuzzily -
    check the printed mapping against your copy of the CSV."""
    df = pd.read_csv(csv_path)
    cols = {
        "glucose": _find_col(df, "glucose"), "systolic": _find_col(df, "systolic", "sbp"),
        "diastolic": _find_col(df, "diastolic", "dbp"), "pulse": _find_col(df, "pulse", "heartrate"),
        "bmi": _find_col(df, "bmi"),
    }
    print("DiaBD column mapping:", cols)
    rng = np.random.default_rng(seed)
    out = {}
    for i, row in df.head(max_patients).iterrows():
        base = {k: float(row[c]) for k, c in cols.items() if c is not None and pd.notna(row[c])}
        out[f"D{i:05d}"] = synth_patient(rng, n_steps, episodes, baseline=base)
    return out


def subject_split(ids: list[str], fr=(0.70, 0.15, 0.15), seed: int = 42):
    """Patient-independent split: no patient appears in two subsets (Sec. 3.9.1)."""
    ids = sorted(ids)
    rng = np.random.default_rng(seed)
    rng.shuffle(ids)
    n = len(ids)
    a, b = int(n * fr[0]), int(n * (fr[0] + fr[1]))
    return ids[:a], ids[a:b], ids[b:]


def make_windows(filtered_scaled: np.ndarray, flags: np.ndarray, seq_len: int = C.SEQ_LEN,
                 horizon: int = C.HORIZON_STEPS) -> tuple[np.ndarray, np.ndarray]:
    """Windows for ONE patient. Sample ending at step e sees only steps <= e.

    Returns X (N, seq_len, 1, 6, 6) float32 and y (N,) where y = emergency within (e, e+horizon].
    """
    n = len(filtered_scaled)
    need = C.GRID + seq_len - 1
    if n < need + 1:
        return np.zeros((0, seq_len, 1, C.GRID, C.N_FEATURES), np.float32), np.zeros(0, np.int64)
    grids = sliding_window_view(filtered_scaled, C.GRID, axis=0)          # (n-5, F, 6)
    grids = np.swapaxes(grids, 1, 2)                                       # (n-5, 6 time, F)
    seqs = sliding_window_view(grids, seq_len, axis=0)                     # (n-5-T+1, 6, F, T)
    seqs = np.moveaxis(seqs, -1, 1)[:, :, None, :, :].astype(np.float32)   # (N, T, 1, 6, F)
    ends = np.arange(seqs.shape[0]) + (need - 1)
    y_all = future_labels(flags, horizon)
    return seqs, y_all[ends]


@dataclass
class Prepared:
    X_train: np.ndarray; y_train: np.ndarray
    X_val: np.ndarray; y_val: np.ndarray
    X_test: np.ndarray; y_test: np.ndarray
    scaler: MinMaxScaler
    split_ids: tuple


def prepare(cohort: dict[str, np.ndarray], seed: int = 42, seq_len: int = C.SEQ_LEN) -> Prepared:
    """Leakage-safe pipeline (Sec. 3.9.3): causal Kalman -> split by patient -> scaler fit on
    TRAIN patients only -> per-patient windows (no window crosses a patient boundary)."""
    filt = {pid: CausalKalman().filter_series(raw) for pid, raw in cohort.items()}
    flags = {pid: emergency_mask(raw) for pid, raw in cohort.items()}
    tr, va, te = subject_split(list(cohort), seed=seed)
    scaler = MinMaxScaler().fit(np.concatenate([filt[p] for p in tr]))

    def build(ids):
        xs, ys = zip(*(make_windows(scaler.transform(filt[p]), flags[p], seq_len) for p in ids))
        return np.concatenate(xs), np.concatenate(ys)

    (Xtr, ytr), (Xva, yva), (Xte, yte) = build(tr), build(va), build(te)
    return Prepared(Xtr, ytr, Xva, yva, Xte, yte, scaler, (tr, va, te))
