"""Train / validate / test the hybrid CNN-LSTM with the leakage-safe protocol of Sec. 3.9.

    python -m iomt.train --patients 500 --epochs 100 --out models/run1
    python -m iomt.train --diabd data/diabd.csv --out models/diabd

The test split is touched exactly once, after the threshold tau is fixed on validation data.
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np
import torch
import torch.nn as nn

from . import config as C
from .data import prepare, synthetic_cohort, trajectories_from_diabd
from .metrics import bootstrap_ci, compute_metrics, select_threshold
from .model import HybridCNNLSTM


def predict(model, X, device, bs=512):
    model.eval()
    out = []
    with torch.no_grad():
        for i in range(0, len(X), bs):
            xb = torch.from_numpy(X[i:i + bs]).to(device)
            out.append(model.predict_proba(xb).cpu().numpy())
    return np.concatenate(out)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--patients", type=int, default=500)
    ap.add_argument("--steps", type=int, default=288, help="15-min steps per patient (288 = 3 days)")
    ap.add_argument("--diabd", help="path to DiaBD CSV (baselines for simulated trajectories)")
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--patience", type=int, default=10)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="models/run")
    a = ap.parse_args()

    torch.manual_seed(a.seed); np.random.seed(a.seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    cohort = (trajectories_from_diabd(a.diabd, a.steps, seed=a.seed, max_patients=a.patients)
              if a.diabd else synthetic_cohort(a.patients, a.steps, seed=a.seed))
    d = prepare(cohort, seed=a.seed)
    print(f"train {d.X_train.shape} pos={d.y_train.mean():.3f} | val {d.X_val.shape} | test {d.X_test.shape}")

    model = HybridCNNLSTM().to(dev)
    opt = torch.optim.Adam(model.parameters(), lr=a.lr)
    sched = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.1 ** (1 / a.epochs))  # decays by 0.1 over training
    loss_fn = nn.CrossEntropyLoss()
    Xtr, ytr = torch.from_numpy(d.X_train), torch.from_numpy(d.y_train)

    best, bad = float("inf"), 0
    os.makedirs(a.out, exist_ok=True)
    for ep in range(a.epochs):
        model.train()
        perm = torch.randperm(len(Xtr))
        tot = 0.0
        for i in range(0, len(perm), a.batch):
            idx = perm[i:i + a.batch]
            opt.zero_grad()
            loss = loss_fn(model(Xtr[idx].to(dev)), ytr[idx].to(dev))
            loss.backward(); opt.step()
            tot += loss.item() * len(idx)
        sched.step()
        model.eval()
        with torch.no_grad():
            vl = sum(loss_fn(model(torch.from_numpy(d.X_val[i:i + 512]).to(dev)),
                             torch.from_numpy(d.y_val[i:i + 512]).to(dev)).item() * len(d.X_val[i:i + 512])
                     for i in range(0, len(d.X_val), 512)) / len(d.X_val)
        print(f"epoch {ep + 1:3d} train_loss={tot / len(Xtr):.4f} val_loss={vl:.4f}")
        if vl < best - 1e-4:
            best, bad = vl, 0
            torch.save({"edge": model.edge.state_dict(), "cloud": model.cloud.state_dict()},
                       os.path.join(a.out, "model.pt"))
        else:
            bad += 1
            if bad >= a.patience:
                print("early stopping"); break

    ck = torch.load(os.path.join(a.out, "model.pt"), map_location=dev)
    model.edge.load_state_dict(ck["edge"]); model.cloud.load_state_dict(ck["cloud"])
    tau = select_threshold(d.y_val, predict(model, d.X_val, dev))      # validation only
    p_test = predict(model, d.X_test, dev)                              # test touched once
    m = compute_metrics(d.y_test, p_test, tau)
    ci = bootstrap_ci(d.y_test, p_test, tau, n_boot=1000)
    print(f"tau={tau:.2f}")
    for k, v in m.items():
        if k in ci:
            print(f"{k:12s} {v:.4f}  95% CI [{ci[k][0]:.4f}, {ci[k][1]:.4f}]")
    json.dump({"tau": tau, "scaler": d.scaler.to_dict(), "metrics": m, "ci": ci,
               "seq_len": C.SEQ_LEN}, open(os.path.join(a.out, "meta.json"), "w"), indent=2)


if __name__ == "__main__":
    main()
