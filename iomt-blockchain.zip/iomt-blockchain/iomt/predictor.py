"""Edge/cloud predictor interfaces.

  TorchPredictor    - loads the trained CNN (edge) and LSTM (cloud) from `models/<run>/`.
  HeuristicPredictor- dependency-free stand-in (trend extrapolation) so the demo, tests and
                      benchmarks run without PyTorch. NOT a clinical model.
"""
from __future__ import annotations

import json
import os
from typing import Protocol

import numpy as np

from . import config as C
from .emergency_rules import emergency_mask
from .preprocessing import MinMaxScaler


class Predictor(Protocol):
    tau: float
    scaler: MinMaxScaler
    def edge_features(self, grid: np.ndarray) -> np.ndarray: ...      # (6,6) scaled -> feature vector
    def cloud_predict(self, feats: np.ndarray) -> float: ...          # (T, D) -> risk in [0,1]


class TorchPredictor:
    def __init__(self, model_dir: str, device: str = "cpu") -> None:
        import torch
        from .model import CloudLSTM, EdgeCNN
        self.torch = torch
        meta = json.load(open(os.path.join(model_dir, "meta.json")))
        self.tau = float(meta["tau"])
        self.scaler = MinMaxScaler.from_dict(meta["scaler"])
        ck = torch.load(os.path.join(model_dir, "model.pt"), map_location=device)
        self.edge, self.cloud = EdgeCNN().to(device), CloudLSTM().to(device)
        self.edge.load_state_dict(ck["edge"]); self.cloud.load_state_dict(ck["cloud"])
        self.edge.eval(); self.cloud.eval()
        self.device = device

    def edge_features(self, grid: np.ndarray) -> np.ndarray:
        with self.torch.no_grad():
            x = self.torch.from_numpy(grid.astype(np.float32))[None, None].to(self.device)
            return self.edge(x)[0].cpu().numpy()

    def cloud_predict(self, feats: np.ndarray) -> float:
        with self.torch.no_grad():
            x = self.torch.from_numpy(feats.astype(np.float32))[None].to(self.device)
            return float(self.torch.softmax(self.cloud(x), -1)[0, 1])


class HeuristicPredictor:
    """Linearly extrapolates the last 6 steps one horizon ahead and checks the clinical rules."""

    def __init__(self, scaler: MinMaxScaler, tau: float = C.DEFAULT_TAU) -> None:
        self.scaler, self.tau = scaler, tau

    def edge_features(self, grid: np.ndarray) -> np.ndarray:
        return grid.reshape(-1).astype(np.float32)  # 36-d "features" = the grid itself

    def cloud_predict(self, feats: np.ndarray) -> float:
        grid = feats[-1].reshape(C.GRID, C.N_FEATURES)
        raw = self.scaler.inverse(grid)
        t = np.arange(C.GRID)
        slope = np.polyfit(t, raw, 1)[0]
        future = raw[-1] + slope * (np.arange(1, C.HORIZON_STEPS + 1)[:, None])
        hit = emergency_mask(np.vstack([raw[-1:], future])).any()
        return 0.95 if hit else 0.05


def default_scaler() -> MinMaxScaler:
    """Scaler spanning plausible physiological ranges (demo / tests only; real runs load meta.json)."""
    sc = MinMaxScaler()
    sc.lo = np.array([40.0, 90.0, 50.0, 40.0, 80.0, 18.0])
    sc.hi = np.array([420.0, 205.0, 125.0, 175.0, 100.0, 45.0])
    return sc
