"""Physician-side retrieval (Algorithms 2 and 5): fetch blob, verify anchor, get wrapped key, decrypt."""
from __future__ import annotations

import json
import secrets
import time

from .crypto import decrypt, sha256_hex, unwrap_key


class IntegrityError(Exception):
    pass


class AccessDenied(Exception):
    pass


class PhysicianClient:
    def __init__(self, physician_id: str, private_pem: bytes, ledger, storage, clock=time.time) -> None:
        self.id, self.priv, self.ledger, self.storage = physician_id, private_pem, ledger, storage
        self.clock = clock

    def read_record(self, patient_id: str, record_id: str) -> dict:
        rec = next(r for r in self.ledger.list_records(patient_id) if r["record_id"] == record_id)
        resp = self.ledger.request_key(self.id, patient_id, rec["key_id"], self.clock(), secrets.token_hex(8))
        if not resp.granted:
            raise AccessDenied(resp.reason)
        blob = self.storage.get(rec["ipfs_cid"])
        if sha256_hex(blob) != rec["sha256"]:
            raise IntegrityError("off-chain blob does not match the hash anchored on the ledger")
        key = unwrap_key(self.priv, resp.wrapped_key)
        try:
            return json.loads(decrypt(key, blob, f"{patient_id}|{record_id}".encode()))
        except Exception as e:  # InvalidTag: ciphertext or AAD modified
            raise IntegrityError("authentication tag check failed") from e
