"""Off-chain encrypted payload storage (paper Sec. 3.4, Algorithm 4/5).

  IPFSStorage  - talks to a (private) Kubo node over its HTTP API (/api/v0/add, /cat).
  LocalStorage - content-addressed directory; drop-in replacement for tests / no-Docker demos.

Only ciphertext ever reaches storage. The ledger anchors (sha256, ipfs_cid); retrieval
re-hashes the blob and compares with the anchored sha256 before decrypting.
"""
from __future__ import annotations

import os
from typing import Protocol

import requests

from .crypto import sha256_hex


class Storage(Protocol):
    def put(self, data: bytes) -> str: ...
    def get(self, ref: str) -> bytes: ...


class LocalStorage:
    def __init__(self, root: str = ".local_store") -> None:
        self.root = root
        os.makedirs(root, exist_ok=True)

    def put(self, data: bytes) -> str:
        ref = "local-" + sha256_hex(data)
        with open(os.path.join(self.root, ref), "wb") as f:
            f.write(data)
        return ref

    def get(self, ref: str) -> bytes:
        with open(os.path.join(self.root, ref), "rb") as f:
            return f.read()


class MemoryStorage:
    def __init__(self) -> None:
        self.blobs: dict[str, bytes] = {}

    def put(self, data: bytes) -> str:
        ref = "mem-" + sha256_hex(data)
        self.blobs[ref] = data
        return ref

    def get(self, ref: str) -> bytes:
        return self.blobs[ref]


class IPFSStorage:
    def __init__(self, api: str = "http://127.0.0.1:5001", timeout: float = 10.0) -> None:
        self.api, self.timeout = api.rstrip("/"), timeout

    def put(self, data: bytes) -> str:
        r = requests.post(f"{self.api}/api/v0/add", params={"pin": "true", "cid-version": "1"},
                          files={"file": ("payload.bin", data)}, timeout=self.timeout)
        r.raise_for_status()
        return r.json()["Hash"]

    def get(self, ref: str) -> bytes:
        r = requests.post(f"{self.api}/api/v0/cat", params={"arg": ref}, timeout=self.timeout)
        r.raise_for_status()
        return r.content
