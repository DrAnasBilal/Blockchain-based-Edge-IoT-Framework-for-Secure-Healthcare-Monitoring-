"""Edge gateway (Raspberry Pi tier) - ties the paper's pipeline together (Fig. 2, Fig. 3).

Per reading:
  1. causal Kalman filter + min-max scaling            (edge processing)
  2. clinical-rule check on the raw reading            (critical / fallback path, no cloud needed)
  3. AES-256-GCM encrypt -> SHA-256 -> store off-chain -> anchor on ledger
  4. once 6 steps are buffered: edge CNN features -> cloud LSTM risk score
  5. risk >= tau (or rule hit) -> emergency alert + on-chain emergency event
"""
from __future__ import annotations

import json
import time
import uuid
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from . import config as C
from .crypto import KeyManager
from .emergency_rules import emergency_mask, emergency_reasons
from .preprocessing import CausalKalman


@dataclass
class _PatientState:
    kalman: CausalKalman = field(default_factory=CausalKalman)
    window: deque = field(default_factory=lambda: deque(maxlen=C.GRID))
    feats: deque = field(default_factory=lambda: deque(maxlen=C.SEQ_LEN))
    keys: Optional[KeyManager] = None


@dataclass
class IngestResult:
    record_id: str
    sha256: str
    storage_ref: str
    key_id: str
    risk: Optional[float]
    emergency: bool
    reasons: list
    alert_id: Optional[str]
    timings_ms: dict


class EdgeGateway:
    def __init__(self, gateway_id: str, ledger, storage, predictor, cloud, tau: Optional[float] = None) -> None:
        self.id, self.ledger, self.storage = gateway_id, ledger, storage
        self.predictor, self.cloud = predictor, cloud
        self.tau = predictor.tau if tau is None else tau
        self.scaler = predictor.scaler
        self._state: dict[str, _PatientState] = {}

    def _patient(self, pid: str) -> _PatientState:
        st = self._state.get(pid)
        if st is None:
            st = _PatientState()
            st.keys = KeyManager(on_new_key=lambda rec, pid=pid: self.ledger.store_key(self.id, pid, rec.key_id, rec.key))
            self._state[pid] = st
        return st

    def ingest(self, patient_id: str, ts: float, reading: np.ndarray) -> IngestResult:
        T = {}
        t = time.perf_counter()
        st = self._patient(patient_id)
        raw = np.asarray(reading, float)
        filt = st.kalman.update(raw)
        scaled = self.scaler.transform(filt)
        st.window.append(scaled)
        T["edge_processing"] = (time.perf_counter() - t) * 1e3

        rule_hit = bool(emergency_mask(raw)[0])
        reasons = emergency_reasons(raw) if rule_hit else []

        # --- encrypt -> off-chain store -> anchor ---
        t = time.perf_counter()
        record_id = uuid.uuid4().hex
        aad = f"{patient_id}|{record_id}".encode()   # binds ciphertext to its ledger record
        payload = json.dumps({"patient": patient_id, "ts": ts, "raw": raw.tolist(),
                              "filtered": filt.tolist(), "features": C.FEATURES}).encode()
        enc = st.keys.encrypt(payload, aad)
        T["encryption"] = (time.perf_counter() - t) * 1e3
        t = time.perf_counter()
        ref = self.storage.put(enc.blob)
        T["offchain_store"] = (time.perf_counter() - t) * 1e3
        t = time.perf_counter()
        self.ledger.anchor_record(self.id, record_id, patient_id, enc.sha256, ref, enc.key_id)
        T["ledger_commit"] = (time.perf_counter() - t) * 1e3

        # --- split inference: CNN at the edge, LSTM in the cloud ---
        risk = None
        t = time.perf_counter()
        if len(st.window) == C.GRID:
            st.feats.append(self.predictor.edge_features(np.stack(st.window)))
            if len(st.feats) == C.SEQ_LEN:
                try:
                    risk = self.cloud.infer(patient_id, np.stack(st.feats))
                except Exception:          # cloud unreachable -> rely on the local rule path
                    risk = None
        T["inference"] = (time.perf_counter() - t) * 1e3

        emergency = rule_hit or (risk is not None and risk >= self.tau)
        alert_id = None
        t = time.perf_counter()
        if emergency:
            source = "rules" if rule_hit else "model"
            eid = f"{patient_id}-{int(ts)}"
            alert = {"patient_id": patient_id, "ts": ts, "risk": risk, "source": source,
                     "reasons": reasons, "record_id": record_id}
            try:
                alert_id = self.cloud.alert(alert)
            except Exception:
                alert_id = None            # a real deployment would fall back to SMS/pager here
            self.ledger.record_emergency(self.id, eid, patient_id, float(risk if risk is not None else 1.0), source)
        T["alert_dispatch"] = (time.perf_counter() - t) * 1e3
        T["total"] = sum(T.values())
        return IngestResult(record_id, enc.sha256, ref, enc.key_id, risk, emergency, reasons, alert_id, T)
