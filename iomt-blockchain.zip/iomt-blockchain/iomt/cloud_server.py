"""Cloud / medical-server tier (FastAPI): LSTM inference, emergency gateway (WebSocket),
clinician confirmation and the timeout monitor with fallback path.

    IOMT_MODEL_DIR=models/run1 uvicorn iomt.cloud_server:app --port 8000
    # mTLS (paper Sec. 4.3):
    uvicorn iomt.cloud_server:app --ssl-keyfile server.key --ssl-certfile server.crt \
            --ssl-ca-certs ca.crt --ssl-cert-reqs 2

Env: IOMT_MODEL_DIR (trained model; omit to use the heuristic stand-in), IOMT_CONFIRM_TIMEOUT_S.
"""
from __future__ import annotations

import asyncio
import os
import time

import numpy as np
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from . import config as C
from .alerts import AlertHub
from .predictor import HeuristicPredictor, TorchPredictor, default_scaler

app = FastAPI(title="IoMT cloud tier")

_model_dir = os.environ.get("IOMT_MODEL_DIR")
if _model_dir:
    predictor = TorchPredictor(_model_dir)
else:  # no trained model: dependency-free heuristic stand-in
    predictor = HeuristicPredictor(default_scaler())

hub = AlertHub(confirm_timeout_s=float(os.environ.get("IOMT_CONFIRM_TIMEOUT_S", "30")))


class InferReq(BaseModel):
    patient_id: str
    features: list[list[float]]   # (T, D) edge-CNN feature vectors


class AlertReq(BaseModel):
    patient_id: str
    ts: float
    risk: float | None = None
    source: str
    reasons: list[str] = []
    record_id: str | None = None


class ConfirmReq(BaseModel):
    clinician_id: str


@app.post("/v1/infer")
def infer(req: InferReq):
    t = time.perf_counter()
    risk = predictor.cloud_predict(np.asarray(req.features, dtype=np.float32))
    return {"risk": risk, "emergency": risk >= predictor.tau, "latency_ms": (time.perf_counter() - t) * 1e3}


@app.post("/v1/alerts")
def create_alert(req: AlertReq):
    return {"alert_id": hub.dispatch(req.model_dump())}


@app.post("/v1/alerts/{alert_id}/confirm")
def confirm(alert_id: str, req: ConfirmReq):
    if not hub.confirm(alert_id, req.clinician_id):
        raise HTTPException(404, "unknown or already confirmed alert")
    return {"status": "confirmed"}


@app.websocket("/ws/clinician")
async def clinician_ws(ws: WebSocket, channel: str = "primary"):
    """Clinicians connect here to receive alerts. channel=fallback receives escalations."""
    await ws.accept()
    loop, q = asyncio.get_running_loop(), asyncio.Queue()
    unsub = hub.subscribe(lambda a: loop.call_soon_threadsafe(q.put_nowait, a), channel)
    try:
        while True:
            await ws.send_json(await q.get())
    except WebSocketDisconnect:
        pass
    finally:
        unsub()


@app.on_event("startup")
async def _monitor():
    async def loop():
        while True:
            hub.check_timeouts()
            await asyncio.sleep(1.0)
    asyncio.create_task(loop())
