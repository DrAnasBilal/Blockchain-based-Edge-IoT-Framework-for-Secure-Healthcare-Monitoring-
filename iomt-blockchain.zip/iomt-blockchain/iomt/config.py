"""Shared constants. Values follow the paper (Sections 3.6, 3.8, 3.9, 4.1) unless noted."""
from __future__ import annotations

# Order matters: this is the column order of every (n, 6) array in the project.
FEATURES = ["glucose", "systolic", "diastolic", "pulse", "spo2", "bmi"]
N_FEATURES = len(FEATURES)
IDX = {name: i for i, name in enumerate(FEATURES)}

GRID = 6                 # 6 time steps x 6 features -> 6x6 grid (Sec. 3.6)
SEQ_LEN = 4              # number of consecutive grids fed to the LSTM (the paper's "T")
STEP_MINUTES = 15        # CGM sampling interval (Sec. 4.6)
HORIZON_MINUTES = 60     # prediction window (Sec. 3.9.2)
HORIZON_STEPS = HORIZON_MINUTES // STEP_MINUTES

# Clinical emergency thresholds (Sec. 4.1). Pulse limits are NOT given numerically
# in the paper; 40 / 150 bpm are an assumption you should review with a clinician.
GLUCOSE_LOW = 54.0       # mg/dL
GLUCOSE_HIGH = 350.0     # mg/dL
SYSTOLIC_CRISIS = 180.0  # mmHg
DIASTOLIC_CRISIS = 120.0 # mmHg
SPO2_LOW = 90.0          # %
PULSE_LOW = 40.0         # bpm (assumed)
PULSE_HIGH = 150.0       # bpm (assumed)

DEFAULT_TAU = 0.48       # decision threshold reported in Sec. 3.9.4 (re-tuned on validation data)

# Crypto / key lifecycle (Sec. 3.8)
KEY_ROTATE_SECONDS = 24 * 3600
KEY_ROTATE_TX = 10_000

# Ledger
CHANNEL = "healthcare"
CHAINCODE = "healthcc"
PDC_COLLECTION = "PDCPatientKeys"
REQUEST_FRESHNESS_S = 60
BREAK_GLASS_TTL_S = 3600
