import unittest

from cryptography.exceptions import InvalidTag

from iomt.crypto import (KeyManager, NonceGenerator, decrypt, generate_rsa_keypair, sha256_hex,
                         unwrap_key, wrap_key)
from tests.helpers import Clock


class CryptoTests(unittest.TestCase):
    def test_roundtrip_and_tamper(self):
        km = KeyManager()
        e = km.encrypt(b"glucose=54", b"aad")
        self.assertEqual(decrypt(km.get_key(e.key_id), e.blob, b"aad"), b"glucose=54")
        bad = bytearray(e.blob); bad[-1] ^= 1
        with self.assertRaises(InvalidTag):
            decrypt(km.get_key(e.key_id), bytes(bad), b"aad")
        with self.assertRaises(InvalidTag):
            decrypt(km.get_key(e.key_id), e.blob, b"other-aad")
        self.assertEqual(e.sha256, sha256_hex(e.blob))

    def test_nonces_unique_and_12_bytes(self):
        g = NonceGenerator()
        ns = {g.next() for _ in range(5000)}
        self.assertEqual(len(ns), 5000)
        self.assertTrue(all(len(n) == 12 for n in ns))

    def test_rotation_by_count_and_time(self):
        clk = Clock()
        km = KeyManager(rotate_after_s=100, rotate_after_tx=3, clock=clk)
        ids = [km.encrypt(b"x").key_id for _ in range(4)]
        self.assertEqual(len(set(ids)), 2)           # rotated after 3 uses
        clk.t += 101
        self.assertNotEqual(km.encrypt(b"x").key_id, ids[-1])
        # retired keys remain available for audit
        self.assertIsNotNone(km.get_key(ids[0]))

    def test_key_wrapping(self):
        priv, pub = generate_rsa_keypair(2048)
        k = b"k" * 32
        self.assertEqual(unwrap_key(priv, wrap_key(pub, k)), k)
        other_priv, _ = generate_rsa_keypair(2048)
        with self.assertRaises(Exception):
            unwrap_key(other_priv, wrap_key(pub, k))


if __name__ == "__main__":
    unittest.main()
