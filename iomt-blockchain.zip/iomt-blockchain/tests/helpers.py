import numpy as np

from iomt.alerts import AlertHub
from iomt.cloud_client import LocalCloud
from iomt.crypto import generate_rsa_keypair
from iomt.edge_gateway import EdgeGateway
from iomt.ledger import MockLedger
from iomt.physician_client import PhysicianClient
from iomt.predictor import HeuristicPredictor, default_scaler
from iomt.storage import MemoryStorage


class Clock:
    def __init__(self, t=1_000_000.0): self.t = t
    def __call__(self): return self.t


def build_world(clock=None):
    clock = clock or Clock()
    ledger = MockLedger(clock=clock)
    ledger.bootstrap_admin("admin")
    priv, pub = generate_rsa_keypair(2048)
    ledger.register_identity("admin", "gw1", "edge")
    ledger.register_identity("admin", "cloud", "service")
    ledger.register_identity("admin", "pat1", "patient")
    ledger.register_identity("admin", "doc1", "physician", pub)
    storage = MemoryStorage()
    hub = AlertHub()
    pred = HeuristicPredictor(default_scaler())
    gw = EdgeGateway("gw1", ledger, storage, pred, LocalCloud(pred, hub))
    doc = PhysicianClient("doc1", priv, ledger, storage, clock=clock)
    return dict(clock=clock, ledger=ledger, storage=storage, hub=hub, gw=gw, doc=doc, priv=priv, pub=pub)


STABLE = np.array([140.0, 128.0, 80.0, 76.0, 97.0, 29.0])
