import unittest

import numpy as np

from iomt import config as C
from iomt.data import make_windows, prepare, subject_split, synthetic_cohort
from iomt.emergency_rules import emergency_mask, future_labels
from iomt.preprocessing import CausalKalman, MinMaxScaler, aggregate_packet


class PipelineTests(unittest.TestCase):
    def test_kalman_is_causal(self):
        rng = np.random.default_rng(0)
        a = rng.normal(100, 5, (50, 6))
        b = a.copy(); b[30:] += 50                      # change the FUTURE only
        fa, fb = CausalKalman().filter_series(a), CausalKalman().filter_series(b)
        np.testing.assert_allclose(fa[:30], fb[:30])

    def test_kalman_handles_nan(self):
        k = CausalKalman()
        k.update(np.full(6, 100.0))
        out = k.update(np.array([np.nan] * 6))
        np.testing.assert_allclose(out, 100.0)

    def test_scaler_roundtrip(self):
        x = np.random.default_rng(1).normal(size=(100, 6)) * 10 + 50
        s = MinMaxScaler().fit(x)
        np.testing.assert_allclose(s.inverse(s.transform(x)), x)
        s2 = MinMaxScaler.from_dict(s.to_dict())
        np.testing.assert_allclose(s2.transform(x), s.transform(x))

    def test_aggregate_prefers_recent_and_high_quality(self):
        v = np.array([[10.0] * 6, [20.0] * 6])
        out = aggregate_packet(v, np.array([0.0, 600.0]), np.array([1.0, 1.0]))
        self.assertGreater(out[0], 15)

    def test_future_labels(self):
        f = np.array([0, 0, 0, 1, 0, 0], bool)
        self.assertEqual(future_labels(f, 2).tolist(), [0, 1, 1, 0, 0, 0])

    def test_split_is_patient_disjoint(self):
        ids = [f"P{i}" for i in range(100)]
        tr, va, te = subject_split(ids)
        self.assertEqual((len(tr), len(va), len(te)), (70, 15, 15))
        self.assertFalse(set(tr) & set(va) or set(tr) & set(te) or set(va) & set(te))

    def test_window_shapes_and_no_lookahead(self):
        rng = np.random.default_rng(0)
        data = rng.random((60, 6)).astype(np.float32)
        flags = np.zeros(60, bool); flags[40] = True
        X, y = make_windows(data, flags)
        self.assertEqual(X.shape[1:], (C.SEQ_LEN, 1, C.GRID, C.N_FEATURES))
        # last grid of sample i must equal data[e-5:e+1] with e = i + GRID + SEQ_LEN - 2
        e = 0 + C.GRID + C.SEQ_LEN - 2
        np.testing.assert_allclose(X[0, -1, 0], data[e - C.GRID + 1:e + 1])
        # label of the sample ending at 36 sees steps 37..40 -> positive; sample ending at 40 -> negative
        first_end = C.GRID + C.SEQ_LEN - 2
        self.assertEqual(y[36 - first_end], 1)
        self.assertEqual(y[40 - first_end], 0)

    def test_prepare_scaler_uses_train_only(self):
        d = prepare(synthetic_cohort(40, 120, seed=3), seed=3)
        self.assertGreater(d.y_train.mean(), 0.05)
        self.assertEqual(d.X_train.shape[1:], (C.SEQ_LEN, 1, 6, 6))
        # Scaler bounds equal min/max of the training patients only
        self.assertEqual(len(d.scaler.lo), 6)

    def test_rules(self):
        arr = np.array([[100, 120, 80, 70, 97, 28], [45, 120, 80, 70, 97, 28], [100, 190, 80, 70, 97, 28],
                        [100, 120, 80, 70, 85, 28]], float)
        self.assertEqual(emergency_mask(arr).tolist(), [False, True, True, True])


if __name__ == "__main__":
    unittest.main()
