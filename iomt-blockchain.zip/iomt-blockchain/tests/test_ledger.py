import secrets
import unittest

from iomt.ledger import LedgerError
from iomt.crypto import generate_rsa_keypair
from tests.helpers import build_world


class LedgerTests(unittest.TestCase):
    def setUp(self):
        self.w = build_world()
        self.L = self.w["ledger"]
        self.L.store_key("gw1", "pat1", "k1", b"K" * 32)
        self.now = self.w["clock"]()

    def req(self, who="doc1", ts=None):
        return self.L.request_key(who, "pat1", "k1", self.now if ts is None else ts, secrets.token_hex(6))

    def test_no_consent_denied_and_logged(self):
        r = self.req()
        self.assertFalse(r.granted)
        self.assertEqual(self.L.get_access_log("pat1")[-1]["outcome"], "denied")

    def test_grant_then_revoke(self):
        self.L.grant_access("pat1", "pat1", "doc1", self.now + 1000)
        self.assertTrue(self.req().granted)
        self.L.revoke_access("pat1", "pat1", "doc1")
        self.assertFalse(self.req().granted)

    def test_expired_grant(self):
        self.L.grant_access("pat1", "pat1", "doc1", self.now + 10)
        self.w["clock"].t += 11
        self.assertFalse(self.req(ts=self.w["clock"]()).granted)

    def test_replay_and_stale(self):
        self.L.grant_access("pat1", "pat1", "doc1", self.now + 1000)
        n = "same-nonce"
        self.assertTrue(self.L.request_key("doc1", "pat1", "k1", self.now, n).granted)
        self.assertEqual(self.L.request_key("doc1", "pat1", "k1", self.now, n).reason, "replayed nonce")
        self.assertEqual(self.req(ts=self.now - 600).reason, "stale timestamp")

    def test_admin_and_edge_cannot_read_keys(self):
        for who in ("admin", "gw1", "pat1"):
            with self.assertRaises(LedgerError):
                self.req(who)

    def test_only_patient_grants_own_data(self):
        self.L.register_identity("admin", "pat2", "patient")
        with self.assertRaises(LedgerError):
            self.L.grant_access("pat2", "pat1", "doc1", self.now + 100)
        with self.assertRaises(LedgerError):
            self.L.grant_access("doc1", "pat1", "doc1", self.now + 100)

    def test_unregistered_cannot_self_register(self):
        with self.assertRaises(LedgerError):
            self.L.register_identity("mallory", "mallory", "physician", b"x")

    def test_break_glass_is_flagged_for_review(self):
        with self.assertRaises(LedgerError):
            self.L.break_glass("doc1", "pat1", "  ")
        self.L.break_glass("doc1", "pat1", "unconscious trauma patient")
        self.assertTrue(self.req().granted)
        self.assertIn(("pat1", "doc1"), self.L.pending_reviews())
        self.assertIn("break-glass", self.L.get_access_log("pat1")[-1]["detail"])

    def test_append_only_and_chain_integrity(self):
        self.L.anchor_record("gw1", "r1", "pat1", "ab" * 32, "cid", "k1")
        with self.assertRaises(LedgerError):
            self.L.anchor_record("gw1", "r1", "pat1", "cd" * 32, "cid2", "k1")
        self.assertTrue(self.L.verify_chain())
        blk = next(b for b in self.L.chain if "AnchorRecord" in b["tx"])
        blk["tx"] = blk["tx"].replace("pat1", "pat9")
        self.assertFalse(self.L.verify_chain())


if __name__ == "__main__":
    unittest.main()
