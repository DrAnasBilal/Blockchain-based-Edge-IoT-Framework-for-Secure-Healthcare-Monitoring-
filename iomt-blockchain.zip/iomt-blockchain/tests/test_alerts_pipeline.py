import unittest

import numpy as np

from iomt.alerts import AlertHub
from iomt.physician_client import AccessDenied, IntegrityError
from tests.helpers import STABLE, Clock, build_world


class AlertTests(unittest.TestCase):
    def test_dispatch_confirm_and_fallback(self):
        clk = Clock(0.0)
        hub = AlertHub(confirm_timeout_s=30, clock=clk)
        primary, fallback = [], []
        hub.subscribe(primary.append); hub.subscribe(fallback.append, "fallback")
        a1, a2 = hub.dispatch({"patient_id": "p1"}), hub.dispatch({"patient_id": "p2"})
        self.assertEqual(len(primary), 2)
        self.assertTrue(hub.confirm(a1, "doc1"))
        clk.t = 31
        self.assertEqual(hub.check_timeouts(), [a2])
        self.assertEqual(fallback[0]["type"], "fallback_escalation")
        self.assertEqual(hub.check_timeouts(), [])      # escalates once


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.w = build_world()
        self.pat_t = self.w["clock"]()

    def feed(self, readings):
        return [self.w["gw"].ingest("pat1", self.pat_t + 900 * i, np.asarray(r, float)) for i, r in enumerate(readings)]

    def test_end_to_end_encrypt_anchor_retrieve(self):
        res = self.feed([STABLE] * 3)[-1]
        L = self.w["ledger"]
        L.grant_access("pat1", "pat1", "doc1", self.pat_t + 3600)
        data = self.w["doc"].read_record("pat1", res.record_id)
        self.assertEqual(data["patient"], "pat1")
        self.assertEqual(len(data["raw"]), 6)
        # storage holds ciphertext only
        blob = self.w["storage"].get(res.storage_ref)
        self.assertNotIn(b"pat1", blob)

    def test_tampered_offchain_blob_detected(self):
        res = self.feed([STABLE])[0]
        self.w["ledger"].grant_access("pat1", "pat1", "doc1", self.pat_t + 3600)
        st = self.w["storage"]; b = bytearray(st.blobs[res.storage_ref]); b[20] ^= 1
        st.blobs[res.storage_ref] = bytes(b)
        with self.assertRaises(IntegrityError):
            self.w["doc"].read_record("pat1", res.record_id)

    def test_no_consent_no_access(self):
        res = self.feed([STABLE])[0]
        with self.assertRaises(AccessDenied):
            self.w["doc"].read_record("pat1", res.record_id)

    def test_rule_path_alerts_immediately(self):
        got = []
        self.w["hub"].subscribe(got.append)
        hypo = np.array([45.0, 128, 80, 76, 97, 29])
        res = self.feed([STABLE] * 2 + [hypo])[-1]
        self.assertTrue(res.emergency)
        self.assertIn("severe_hypoglycemia", res.reasons)
        self.assertEqual(got[-1]["source"], "rules")
        self.assertIn(f"pat1-{int(self.pat_t + 1800)}", self.w["ledger"].emergencies)

    def test_predictive_alert_before_threshold(self):
        got = []
        self.w["hub"].subscribe(got.append)
        glucose = np.linspace(150, 60, 14)                 # falling toward hypoglycemia, never below 54
        rs = self.feed([[g, 128, 80, 76, 97, 29] for g in glucose])
        pred = [r for r in rs if r.emergency and r.risk is not None]
        self.assertTrue(pred, "expected a model-driven early warning")
        self.assertGreater(min(r.timings_ms["total"] for r in rs), 0)

    def test_key_rotation_stores_every_key_in_pdc(self):
        self.feed([STABLE] * 2)
        self.assertEqual(len(self.w["ledger"]._pdc), 1)

    def test_cloud_outage_falls_back_to_rules(self):
        class Down:
            def infer(self, *a): raise ConnectionError
            def alert(self, p): raise ConnectionError
        self.w["gw"].cloud = Down()
        hypo = np.array([45.0, 128, 80, 76, 97, 29])
        res = self.feed([STABLE] * 8 + [hypo])[-1]
        self.assertTrue(res.emergency)              # still detected locally
        self.assertIsNone(res.alert_id)


if __name__ == "__main__":
    unittest.main()
